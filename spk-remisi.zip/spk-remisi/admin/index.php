<?php 
    include ('style/header.php');
    include ('style/sidebarawal.php');
    include ('../config/koneksi.php');
?>
<div class="container-fluid">
	<!-- Basic Card Example -->
	<div class="card shadow mt-3 mb-3">
		<div class="card-header py-3">
			<h6 class="m-0 font-weight-bold text-primary">Dashboard</h6>
		</div>
		<div class="card-body" align="center">
			<h2>Selamat Datang <?php echo $_SESSION['username']; ?></h2>
			<br>
			<h3>Sistem Pendukung Keputusan Metode Simple Additive Weighting (SAW)</h3>
			<h4>Rekomendasi Pemberian RemisiPada Narapidana Di Lembaga Pemasyarakatan Kelas II B Kota Muaro Sijunjung</h4>
		</div>
	</div>
</div>
<?php 
    include ('style/footer.php');
?>