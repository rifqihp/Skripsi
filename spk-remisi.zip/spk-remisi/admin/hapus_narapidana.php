<?php
include ("../config/koneksi.php");
$id_narapidana= $_GET['id'];
// $idp = $_GET['idp'];

$sql1 = mysqli_query($konek,"SELECT * FROM tbl_narapidana WHERE id_narapidana='$id_narapidana'");
$data1 = mysqli_fetch_array($sql1);
$delete = mysqli_query($konek,"DELETE FROM tbl_narapidana WHERE id_narapidana = '$id_narapidana'");

if($delete) {
	echo "<script language=javascript>
	window.alert('Berhasil Menghapus!');
	window.location='data_narapidana.php';
	</script>";
}else{
	echo "<script language=javascript>
	window.alert('Gagal Menghapus!');
	window.location='data_narapidana.php';
	</script>";
}

?>