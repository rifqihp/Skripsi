<?php 
    include ('style/header.php');
    include ('style/sidebar.php');
	include("../config/koneksi.php");
	$id_narapidana = $_GET['id'];
	// $idp = $_GET['idp'];
?>
<div class="container-fluid">
	<!-- Basic Card Example -->
	<div class="card shadow mt-3 mb-3">
		<div class="card-header py-3">
			<h6 class="m-0 font-weight-bold text-primary">Data Narapidana</h6>
		</div>
		<div class="card-body">
		<?php 
			$query = mysqli_query($konek,"SELECT * FROM tbl_narapidana where id_narapidana='$id_narapidana'")or die(mysqli_error());
			while($data = mysqli_fetch_array($query)){
		?>
		<form action="" method="POST" enctype="multipart/form-data">
			<div class="form-group">
			
				<label>Nama Narapidana</label>
      			<input type="text" class="form-control mb-2" name="nama" value="<?php echo $data['nama']; ?>">
      			
      			<label>Tanggal Lahir</label>
      			<input type="text" class="form-control mb-2" name="tgl_lahir" value="<?php echo $data['tgl_lahir']; ?>">

      			<label>Alamat</label>
      			<textarea class="form-control mb-2" name="alamat"><?php echo $data['alamat'] ?></textarea>

      			<label>Agama</label>
            	<select class="form-control mb-2" name="agama">
	              <option>--Agama--</option>
	              <option value="Islam">Islam</option>
	              <option value="Protestan">Protestan</option>
	              <option value="Katolik">Katolik</option>
	              <option value="Hindu">Hindu</option>
	              <option value="Buddha">Buddha</option>
	              <option value="Khonghucu">Khonghucu</option>
	            </select>

	            <label>Perkara</label>
	            <input type="text" class="form-control mb-2" name="perkara" value="<?php echo $data['perkara']; ?>">
	            
	            <label>Tanggal Masuk</label>
	            <input type="date" class="form-control mb-2" name="tgl_masuk" value="<?php echo $data['tgl_masuk']; ?>">

	            <label>Tanggal Keluar</label>
	            <input type="date" class="form-control mb-2" name="tgl_keluar" value="<?php echo $data['tgl_keluar']; ?>">
	            
	            <label>Hukuman</label>
	            <input type="text" class="form-control mb-2" name="hukuman" value="<?php echo $data['hukuman']; ?>">
      		</div>
      	</div>
      	<div class="modal-footer">
      		<button type="submit" name="edit" class="btn btn-success btn-sm" >Edit</button>
      	</div>
		</form>
		<?php 
		}
		?>
	</div>
</div>

<?php
include ("../config/koneksi.php");
if(isset($_POST['edit'])) {

$nama 					= $_POST['nama'];
$tgl_lahir 				= $_POST['tgl_lahir'];
$alamat 				= $_POST['alamat'];
$agama 					= $_POST['agama'];
$perkara				= $_POST['perkara'];
$tgl_masuk 				= $_POST['tgl_masuk'];
$tgl_keluar 			= $_POST['tgl_keluar'];
$hukuman 				= $_POST['hukuman'];

	$sql3 = mysqli_query($konek,"UPDATE tbl_narapidana SET nama = '$nama', tgl_lahir='$tgl_lahir', alamat ='$alamat', perkara ='$perkara', tgl_masuk ='$tgl_masuk', tgl_keluar ='$tgl_keluar', hukuman ='$hukuman' WHERE id_narapidana ='$id_narapidana'"); // Eksekusi/ Jalankan query dari variabel $query

	if($sql3){ // Cek jika proses simpan ke database sukses atau tidak
		// Jika Sukses, Lakukan :
		
		echo "<script language=javascript>
				window.alert('Berhasil Mengedit!');
				window.location='data_narapidana.php?idp=$idp';
				</script>";
	}else{
		// Jika Gagal, Lakukan :
		echo "<script language=javascript>
				window.alert('Gagal Mengedit!');
				window.location='data_narapidana.php?idp=$idp';
				</script>";
	}
}
?>

<?php 
    include ('style/footer.php');
?>