<?php
include ("../config/koneksi.php");
$idp = $_GET['idp'];

$delete = mysqli_query($konek,"DELETE FROM tbl_alternatif WHERE id_periode = '$idp'");
$delete2 = mysqli_query($konek,"DELETE FROM tbl_normalisasi WHERE id_periode = '$idp'");
$delete3 = mysqli_query($konek,"DELETE FROM tbl_penilaian WHERE id_periode = '$idp'");
$delete3 = mysqli_query($konek,"DELETE FROM tbl_hasil WHERE id_periode = '$idp'");
$delete4 = mysqli_query($konek,"DELETE FROM tbl_periode WHERE id_periode = '$idp'");

if($delete) {
	echo "<script language=javascript>
	window.alert('Berhasil Menghapus!');
	window.location='history.php';
	</script>";
}else{
	echo "<script language=javascript>
	window.alert('Gagal Menghapus!');
	window.location='history.php';
	</script>";
}

?>