<?php 
  include("../config/koneksi.php");  
?>
<link rel="stylesheet" type="text/css" href="style/css/bootstrap.css">
<body >
<center>
	<div class="container">
<p style="font-size:30px;padding:0px;margin-bottom:-15px;">LAPAS KELAS II B KOTA MUARO SINJUNJUNG</p>
<p class="mt-3" style="font-size:18px;padding:0px;margin-bottom:-12px;">Jl. Pengayoman, Muaro Sijunjung</p>
<br>
<hr>
<br>
</center>
  <?php 
	$no = 1;
	$q = mysqli_query($konek,"SELECT * FROM  tbl_narapidana");
?>
<div class="container-fluid">
	<h3 align="center">DATA NARAPIDANA<br></h3>
	<table width="100%" style="text-align: left; border-collapse: collapse; " border="1" class="table table-bordered" >
		<tr>
			<thead class="bg-success">
			<th>No</th>
			<th>Nama Narapidana</th>
			<th>Tanggal Lahir</th>
			<th>Jenis Kelamin</th>
			<th>Alamat</th>
			<th>Agama</th>
			<th>Perkara</th>
			<th>Tanggal Masuk</th>
			<th>Tanggal Keluar</th>
			<th>Hukuman</th>
		</thead>
		</tr>
		<?php 
		$no = 1;
		while ($row = mysqli_fetch_array($q)) {
			?>
		<tr>
			<td><?php echo $no; ?></td>
			<td><?php echo $row[1]; ?></td>
			<td><?php echo $row[2]; ?></td>
			<td><?php echo $row[3]; ?></td>
			<td><?php echo $row[4]; ?></td>
			<td><?php echo $row[5]; ?></td>
			<td><?php echo $row[6]; ?></td>
			<td><?php echo $row[7]; ?></td>
			<td><?php echo $row[8]; ?></td>
			<td><?php echo $row[9]; ?></td>
		</tr>
		<?php	
		$no++;
		}
		 ?>
	</table>
</div>
<h4 style="margin-left: 70%; margin-bottom: 5%;">Padang, <?php echo date('d F Y') ?></h3>
<br>
<br>
<h5 style="margin-left: 72%; margin-bottom: 1%;">LAPAS KELAS II B KOTA MUARO SIJUNJUNG</h3> 
</h5>
</h4>
</div>
</center>

</body>

<script type="text/javascript" src="style/js/bootstrap.js"></script>
?>