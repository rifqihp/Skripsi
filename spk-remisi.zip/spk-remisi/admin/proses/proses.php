<?php
include("style/header.php");
include("style/sidebar.php");
include '../../config/koneksi.php';
$idp = $_GET['idp'];
?>
<div class="container-fluid">
	<div class="col-lg-12">
		<!-- Basic Card Example -->
		<div class="card shadow mt-3 mb-3">
			<div class="card-header py-3">
				<h6 class="m-0 font-weight-bold text-primary">Data Proses Perhitungan</h6>
			</div>
			<!-- Data 1 -->
			<div class="card-body">
				<h5>Data Nilai Bobot (W)</h5>
				<div class="table-responsive">
					<table class="table table-bordered">
						<thead>
							<tr align="center">
								<!-- Tampil Data Kriteria -->
								<?php
								$sqltr = mysqli_query($konek, "SELECT * FROM tbl_kriteria");
								while ($rowtr = $sqltr->fetch_array()) {
								?>
									<th><?= $rowtr['nama_kriteria']; ?></th>
								<?php
								}

								?>
								<!-- echo $k1; ?></th>
							<th><?php echo $k2; ?></th>
							<th><?php echo $k3; ?></th>
							<th><?php echo $k4; ?></th>
							<th><?php echo $k5; ?></th>
							<th><?php echo $k6; ?></th> -->

							</tr>
							<tr align="center">
								<!-- Tampil data Jenis Kriteria -->
								<?php
								$sqltr = mysqli_query($konek, "SELECT * FROM tbl_kriteria");
								while ($rowtr = $sqltr->fetch_array()) {
								?>
									<th><?= $rowtr['jenis_kriteria']; ?></th>
								<?php
								}

								?>
								<!-- <th style="font-size: 15px;"><?php echo "($jenis1)"; ?></th>
							<th style="font-size: 15px;"><?php echo "($jenis2)"; ?></th>
							<th style="font-size: 15px;"><?php echo "($jenis3)"; ?></th>
							<th style="font-size: 15px;"><?php echo "($jenis4)"; ?></th>
							<th style="font-size: 15px;"><?php echo "($jenis5)"; ?></th>
							<th style="font-size: 15px;"><?php echo "($jenis6)"; ?></th> -->

							</tr>
						</thead>
						<tbody>


							<tr align="center">
								<!-- Tampil Data Penilaian -->
								<?php
								$sqltr = mysqli_query($konek, "SELECT * FROM tbl_kriteria");
								while ($rowtr = $sqltr->fetch_array()) {
								?>
									<td><?= $rowtr['bobot']; ?></td>
								<?php
								}

								?>
								<!-- <td><?php echo number_format($b1, 2); ?></td>
							<td><?php echo number_format($b2, 2); ?></td>
							<td><?php echo number_format($b3, 2); ?></td>
							<td><?php echo number_format($b4, 2); ?></td>
							<td><?php echo number_format($b5, 2); ?></td>
							<td><?php echo number_format($b6, 2); ?></td> -->

							</tr>
						</tbody>
					</table>
				</div>
			</div>
			<!-- Data 2 -->
			<div class="card-body">
				<h5>Data Penilaian</h5>
				<div class="table-responsive">
					<table class="table table-bordered">
						<thead>
							<tr align="center">
								<th>No</th>
								<th>Nama Alternatif</th>
								<?php
								$sqlth = $konek->query("SELECT * FROM tbl_kriteria");
								while ($rowth = $sqlth->fetch_array()) {
								?>
									<th><?= $rowth['nama_kriteria']; ?></th>
								<?php
								}
								?>

								<!-- <th><?php echo $k1; ?></th>
							<th><?php echo $k2; ?></th>
							<th><?php echo $k3; ?></th>
							<th><?php echo $k4; ?></th>
							<th><?php echo $k5; ?></th>
							<th><?php echo $k6; ?></th> -->

							</tr>
						</thead>
						<tbody>
							<?php
							include('../../config/koneksi.php');
							$no = 1;
							$qq = mysqli_query($konek, "SELECT DISTINCT * FROM tbl_penilaian a LEFT JOIN tbl_alternatif b ON a.id_alternatif=b.id_alternatif JOIN tbl_narapidana c ON b.id_narapidana = c.id_narapidana WHERE a.id_periode = '$idp' AND a.ket = 'B' GROUP BY a.id_alternatif");
							$rowq = mysqli_num_rows($qq);
							if ($rowq > 0) {
							?>
								<!-- Menampilkan nilai -->
								<?php
								$query = mysqli_query($konek, "SELECT DISTINCT * FROM tbl_penilaian a LEFT JOIN tbl_alternatif b ON a.id_alternatif=b.id_alternatif JOIN tbl_narapidana c ON b.id_narapidana = c.id_narapidana WHERE a.id_periode = '$idp' AND a.ket = 'B' GROUP BY a.id_alternatif");
								while ($data = mysqli_fetch_array($query)) {
									$idalt = $data['id_alternatif'];
									$nmalt = $data['nama'];
									$idsub = $data['id_subkriteria'];

								?>
									<tr>
										<td align="right"><?php echo $no++; ?></td>
										<td><?php echo $nmalt; ?></td>
										<?php
										$query2 = $konek->query("SELECT * FROM tbl_penilaian a JOIN tbl_subkriteria b ON a.id_subkriteria = b.id_subkriteria WHERE a.id_alternatif = '$idalt' AND a.id_periode = '$idp'");
										while ($rowq2 = $query2->fetch_array()) {
										?>
											<td><?= $rowq2['nbobot']; ?></td>
										<?php
										}
										?>
									</tr>
								<?php
								}
							} else {
								?>
								<td colspan="7">
									<center>
										<h3>Semua data penilaian sudah diproses.</h3>
									</center>
								</td>
							<?php

							}
							?>


						</tbody>
					</table>
				</div>
			</div>
			<!-- Data 3 -->
			<div class="card-body">
				<h5>Data Nilai Max / Min</h5>
				<div class="table-responsive">
					<table class="table table-bordered">
						<thead>
							<tr align="center">
								<!-- Data nilai MAX -->
								<?php
								$sqlth = $konek->query("SELECT * FROM tbl_kriteria");
								while ($rowth = $sqlth->fetch_array()) {
								?>
									<th><?= $rowth['nama_kriteria']; ?></th>
								<?php
								}
								?>
								<!-- <th><?php echo $k1; ?></th>
							<th><?php echo $k2; ?></th>
							<th><?php echo $k3; ?></th>
							<th><?php echo $k4; ?></th>
							<th><?php echo $k5; ?></th>
							<th><?php echo $k6; ?></th> -->

							</tr>
							<tr align="center">
								<?php
								$sqlth = $konek->query("SELECT * FROM tbl_kriteria");
								while ($rowth = $sqlth->fetch_array()) {
								?>
									<th><?= $rowth['jenis_kriteria']; ?></th>
								<?php
								}
								?>


							</tr>
						</thead>
						<tbody>


							<tr align="center">
								<?php
								$sqlth = $konek->query("SELECT * FROM tbl_kriteria");
								while ($rowth = $sqlth->fetch_array()) {
								?>
									<td><?= $rowth['bobot']; ?></td>
								<?php
								}
								?>


							</tr>
							<form action="" method="POST">
								<tr>
									<td colspan="9">
										<div align="right"><button type="submit" name="proses" class="btn btn-primary">Proses</button>
										</div>

									</td>
								</tr>
							</form>
						</tbody>
					</table>


				</div>
			</div>
		</div>
	</div>
</div>
<?php
if (isset($_POST['proses'])) {

	$sqlp1 = $konek->query("SELECT DISTINCT * FROM tbl_penilaian WHERE id_periode = '$idp' AND ket = 'B' GROUP BY id_alternatif");
	while ($rowp1 = $sqlp1->fetch_array()) {
		$idalt = $rowp1['id_alternatif'];
		$sqlcek = mysqli_query($konek,"SELECT * FROM tbl_normalisasi WHERE id_periode = '$idp' AND id_alternatif = '$idalt'");
		$ceksql2 = mysqli_num_rows($sqlcek);
			if ($ceksql2 > 0) {
			
			} else {
				$sqlkrt = $konek->query("SELECT * FROM tbl_kriteria");
				$nc = 0;
				while ($rowkrt = $sqlkrt->fetch_array()) {
					$idkrt = $rowkrt['id_kriteria'];
					$jnkrt = $rowkrt['jenis_kriteria'];
					$bobot = $rowkrt['bobot'];
					$sqlp2 = $konek->query("SELECT * FROM tbl_penilaian a join tbl_subkriteria b on a.id_subkriteria = b.id_subkriteria JOIN tbl_kriteria c ON b.id_kriteria = c.id_kriteria WHERE a.id_alternatif = '$idalt' AND a.id_periode = '$idp' AND c.id_kriteria = '$idkrt' ");
					while ($rowp2 = $sqlp2->fetch_array()) {
						if ($jnkrt == "Benefit") {
							$sqlceknilai = $konek->query("SELECT MAX(nbobot) as n FROM tbl_penilaian a join tbl_subkriteria b on a.id_subkriteria = b.id_subkriteria JOIN tbl_kriteria c ON b.id_kriteria = c.id_kriteria WHERE a.id_periode = '$idp' AND c.id_kriteria = '$idkrt' ");
							$rown = $sqlceknilai->fetch_array();
							$n = $rown['n'];
							$c = $rowp2['nbobot'];
							$c = $c / $n;
						} else {
							$sqlceknilai = $konek->query("SELECT MIN(nbobot) as n FROM tbl_penilaian a join tbl_subkriteria b on a.id_subkriteria = b.id_subkriteria JOIN tbl_kriteria c ON b.id_kriteria = c.id_kriteria WHERE a.id_periode = '$idp' AND c.id_kriteria = '$idkrt' ");
							$rown = $sqlceknilai->fetch_array();
							$n = $rown['n'];
							$c = $rowp2['nbobot'];
							$c = $n / $c;
						}
						$simpanc = $konek->query("INSERT INTO tbl_normalisasi VALUES ('','$idalt','$idp','$idkrt','$c')");
						$nc += ($c * $bobot);
					}
				}
			}
				
				$simpanakhir = $konek->query("INSERT INTO tbl_hasil VALUES ('','$idalt','$idp','$nc')");
				$updatenilai = $konek->query("UPDATE tbl_penilaian SET ket = 'S' WHERE id_alternatif = '$idalt'");
	}
	echo "<script language=javascript>
          							window.alert('Berhasil!');
          							window.location='proses.php?idp=$idp';
          							</script>";
}

?>
<?php
include("style/footer.php");
?>