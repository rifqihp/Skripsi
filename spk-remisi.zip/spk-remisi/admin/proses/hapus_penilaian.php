<?php 
include "../../config/koneksi.php";

$ids=$_GET['id'];
$idp = $_GET['idp'];
$delete = mysqli_query($konek,"DELETE From tbl_penilaian Where id_alternatif ='$ids'");

if($delete) {
	echo "<script language=javascript>
	window.alert('Berhasil Menghapus!');
	window.location='data_penilaian.php?idp=$idp';
	</script>";
}else{
	echo "<script language=javascript>
	window.alert('Gagal Menghapus!');
	window.location='data_penilaian.php?idp=$idp';
	</script>";
}
?>

