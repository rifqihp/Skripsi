<?php 
    include ('style/header.php');
    include ('style/sidebar.php');
	include("../../config/koneksi.php");
	$ids = $_GET['id'];
	$sqlcek = mysqli_query($konek,"SELECT * FROM tbl_alternatif a join tbl_narapidana b on a.id_narapidana = b.id_narapidana WHERE id_alternatif = '$ids'");
	$data = mysqli_fetch_array($sqlcek);
	//kriteria1
	// $sqlc1 = mysqli_query($konek,"SELECT nama_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT001'");
    // $data1 = mysqli_fetch_array($sqlc1);
    // $k1 = $data1[0];
    //kriteria2
    // $sqlc2 = mysqli_query($konek,"SELECT nama_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT002'");
    // $data2 = mysqli_fetch_array($sqlc2);
    // $k2 = $data2[0];
    //kriteria3
    // $sqlc3 = mysqli_query($konek,"SELECT nama_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT003'");
    // $data3 = mysqli_fetch_array($sqlc3);
    // $k3 = $data3[0];
    //kriteria4
    // $sqlc4 = mysqli_query($konek,"SELECT nama_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT004'");
    // $data4 = mysqli_fetch_array($sqlc4);
    // $k4 = $data4[0];
    // $sqlc5 = mysqli_query($konek,"SELECT nama_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT005'");
    // $data5 = mysqli_fetch_array($sqlc5);
    // $k5 = $data5[0];
    // //kriteria6
    // $sqlc6 = mysqli_query($konek,"SELECT nama_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT006'");
    // $data6 = mysqli_fetch_array($sqlc6);
    // $k6 = $data6[0];
    //kriteria7
    // $sqlc7 = mysqli_query($konek,"SELECT nama_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT007'");
    // $data7 = mysqli_fetch_array($sqlc7);
    // $k7 = $data1[0];
?>
<div class="container-fluid">
	<!-- Basic Card Example -->
	<div class="card shadow mt-3 mb-3">
		<div class="card-header py-3">
			<h6 class="m-0 font-weight-bold text-primary">Edit Data Penilaian <?php echo $data['nama']; ?></h6>
		</div>
		<div class="card-body">
		<?php 
			$query = mysqli_query($konek,"SELECT * FROM tbl_penilaian WHERE id_alternatif='$ids'");
			// while($data = mysqli_fetch_array($query)){
		?>
		<form action="" method="POST" enctype="multipart/form-data">
			<input type="hidden" name="ids" value="<?php echo $ids; ?>">
			<div class="form-group">
              <input type="hidden" name="ids" value="<?php echo $ids; ?>">
      				<!-- C1 -->
      		<!-- Loop -->
              <?php 
				  $c = 1;
				  $x = 1;
				 	$sqlnilai = $konek->query("SELECT * FROM tbl_kriteria");
					 while($rownilai = $sqlnilai->fetch_array()){
						 ?>
							<label><?php echo $rownilai['nama_kriteria']; ?> (C<?= $c++; ?>)</label>
								<select name="k<?= $x; ?>" class="form-control mb-2">
								<option value="#">---Pilih Nilai---	</option>
									<?php 
										$sqlsubs = $konek->query("SELECT * FROM tbl_subkriteria WHERE id_kriteria = '$rownilai[id_kriteria]'");
										while ($rowsubs = $sqlsubs->fetch_array()) {
											?>		
												<option value="<?= $rowsubs['id_subkriteria']; ?>"><?= $rowsubs['ket']; ?></option>
											<?php
										}
									?>
								</select>
						 <?php
						 $x++;
					 } 
				  ?>
            
      		</div>
      	</div>
      	<div class="modal-footer">
      		<button type="submit" name="edit" class="btn btn-success btn-sm" >Edit</button>
      	</div>
		</form>
	</div>
		<?php 
		// }
		?>
	</div>
</div>


<?php
include ("../../config/koneksi.php");

if(isset($_POST['edit'])) {
$sqlcekproses = $konek->query("SELECT * FROM tbl_hasil WHERE id_periode = '$idp'");
$rowcekproses = $sqlcekproses->num_rows;
if ($rowcekproses > 0) {
    $query2 = mysqli_query($konek,"SELECT * FROM tbl_kriteria");
	$rq2 = $query2->num_rows;
	for ($i=1; $i <= $rq2 ; $i++) { 
        $sqlceknilai = $konek->query("SELECT * FROM tbl_penilaian a JOIN tbl_subkriteria b ON a.id_subkriteria = b.id_subkriteria JOIN tbl_kriteria c ON b.id_kriteria = c.id_kriteria WHERE b.id_kriteria = 'KRT00$i' AND id_alternatif = '$ids'");
    $rowceknilai = $sqlceknilai->fetch_array();
    $id_sub = $rowceknilai['id_subkriteria'];
    // echo "<script>alert('ID Subkriteria : $id_sub')</script>";
    
		$n = $_POST["k$i"];
	     $sqledit = mysqli_query($konek,"UPDATE tbl_penilaian SET id_subkriteria = '$n' WHERE id_subkriteria ='$id_sub' AND id_alternatif = '$ids' AND id_periode = '$idp'");
	
         // Eksekusi/ Jalankan query dari variabel $query
         echo "<script>
		 window.alert('Berhasil!');
		 window.location='data_penilaian.php?idp=$idp';
		 </script>";
    }
} else {
   echo "<script language=javascript>
			 window.alert('Ada kesalahan pada proses edit!');
			 window.location='data_penilaian.php?idp=$idp';
			 </script>";
}
}

//   if ($sqledit) {
//     $deletenor = $konek->query("DELETE FROM tbl_normalisasi WHERE id_periode = '$idp'");
//     $deletehasil = $konek->query("DELETE FROM tbl_hasil WHERE id_periode = '$idp'");
//     if ($deletenor && $deletehasil) {
//       include 'function_proses.php';
//     }else{
//        echo "<script language=javascript>
//                window.alert('Ada kesalahan pada proses hapus data!');
//                window.location='data_penilaian.php?idp=$idp';
//                </script>";
//     }


// }else{
//    $sqledit = mysqli_query($konek,"UPDATE tbl_penilaian SET id_alternatif='$ids', c1='$c1', c2='$c2', c3='$c3', c4='$c4', c5='$c5', c6='$c6' WHERE id_alternatif='$ids'"); // Eksekusi/ Jalankan query dari 
//    if ($sqledit) {
//      echo "<script language=javascript>
//                window.alert('Data Berhasil Diedit!');
//                window.location='data_penilaian.php?idp=$idp';
//                </script>";
//    }else{
//     echo "<script language=javascript>
//                window.alert('Data Gagal Diedit!');
//                window.location='data_penilaian.php?idp=$idp';
//                </script>";
//    }
?>

<?php 
    include ('style/footer.php');
?>