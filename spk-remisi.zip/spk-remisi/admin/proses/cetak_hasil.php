<?php
include("../../config/koneksi.php");
$idp = $_GET['idp'];
?>
<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<title>Cetak Hasil</title>
</head>

<body>
	<link rel="stylesheet" type="text/css" href="style/css/bootstrap.css">
	<center>
		<div class="container">
			<p><img src="style/logo1.jpg" width="120px" class="mt-3"></p>
			<p style="font-size:25px;padding:0px;margin-bottom:-15px;"><b>MENTERI HUKUM DAN HAK ASASI MANUSIA REPUBLIK INDONESIA</b></p>
			<p class="mt-3" style="font-size:30px;padding:0px;margin-bottom:-15px;">LAPAS KELAS II B KOTA MUARO SINJUNJUNG</p>
			<p class="mt-3" style="font-size:18px;padding:0px;margin-bottom:-12px;">Jl. Pengayoman, Muaro Sijunjung</p>
			<br>
			<hr>
			<br>
	</center>
	<?php
	$no = 1;
	$q = mysqli_query($konek, "SELECT * FROM  tbl_hasil a LEFT JOIN tbl_alternatif b on a.id_alternatif = b.id_alternatif JOIN tbl_narapidana c ON b.id_narapidana = c.id_narapidana WHERE a.id_periode = '$idp' ORDER BY a.hasil DESC");
	?>
	<div class="container-fluid">
		<h3 align="center">DATA HASIL</h3>
		<table width="100%" style="text-align: left; border-collapse: collapse; " border="1" class="table table-bordered">
			<tr>
				<thead align="center" class="bg-success">
					<th>No</th>
					<th>Nama </th>
					<th>Hasil Rekomendasi</th>
				</thead>
			</tr>
			<?php
			$no = 1;
			while ($row = mysqli_fetch_array($q)) {
			?>
				<tr>
					<td><?php echo $no; ?></td>
					<td align="center"><?php echo $row['nama']; ?></td>
					<td align="center"><?php
										$range = $row['hasil'];
										if ($range >= 0.70) {
											echo "Rekomendasi";
										} else {
											echo "Tidak Rekomendasi";
										}
										?></td>
				</tr>
			<?php
				$no++;
			}
			?>
		</table>
	</div>
	<h4 style="margin-left: 70%;">Sijunjung, <?php echo date('d F Y') ?></h4>
	<p style="margin-left: 70%;">A.n MENTERI HUKUM DAN HAM RI <br> DIREKTUR JENDERAL PEMASYARAKATAN.</p>
	<div style="
	margin-left: 70%;
  border: 5px solid blue;
  padding-top: 10px;
  padding-right: 10px;
  padding-bottom: 10px;
  padding-left: 10px;
">
		<p><img src="style/logo1.jpg" width="100px">Ditandatangin Secara Elektronik Oleh
			<b style="margin-left: 27%;">Reynhard Sitilonga</b>
		</p>
		<p style="margin-left: 27%;">NIP : 670903320000001000</p>
	</div>
	</div>
	</center>

</body>