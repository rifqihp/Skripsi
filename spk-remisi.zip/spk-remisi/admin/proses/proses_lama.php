<?php 
	include ("style/header.php");
	include ("style/sidebar.php");
	include '../../config/koneksi.php';
	$idp = $_GET['idp'];
	//kriteria1
	$sqlc1 = mysqli_query($konek,"SELECT nama_kriteria,bobot,jenis_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT001'");
    $data1 = mysqli_fetch_array($sqlc1);
    $jenis1 = $data1['jenis_kriteria'];
    $k1 = $data1[0];
    $b1 = $data1[1];
    //kriteria2
    $sqlc2 = mysqli_query($konek,"SELECT nama_kriteria,bobot,jenis_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT002'");
    $data2 = mysqli_fetch_array($sqlc2);
    $jenis2 = $data2['jenis_kriteria'];
    $k2 = $data2[0];
    $b2 = $data2[1];
    //kriteria3
    $sqlc3 = mysqli_query($konek,"SELECT nama_kriteria,bobot,jenis_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT003'");
    $data3 = mysqli_fetch_array($sqlc3);
    $jenis3 = $data3['jenis_kriteria'];
    $k3 = $data3[0];
    $b3 = $data3[1];
    //kriteria4
    $sqlc4 = mysqli_query($konek,"SELECT nama_kriteria,bobot,jenis_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT004'");
    $data4 = mysqli_fetch_array($sqlc4);
    $jenis4 = $data4['jenis_kriteria'];
    $k4 = $data4[0];
    $b4 = $data4[1];
    //kriteria5
    $sqlc5 = mysqli_query($konek,"SELECT nama_kriteria,bobot,jenis_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT005'");
    $data5 = mysqli_fetch_array($sqlc5);
    $jenis5 = $data5['jenis_kriteria'];
    $k5 = $data5[0];
    $b5 = $data5[1];
    //kriteria6
    $sqlc6 = mysqli_query($konek,"SELECT nama_kriteria,bobot,jenis_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT006'");
    $data6 = mysqli_fetch_array($sqlc6);
    $jenis6 = $data5['jenis_kriteria'];
    $k6 = $data6[0];
    $b6 = $data6[1];
    
//data max min 
    //c1
   if ($jenis1 == "Benefit") {
   		$sqlm1 = mysqli_query($konek,"SELECT MAX(c1) as max_c1 FROM tbl_penilaian WHERE id_periode = '$idp'");
    	$datam1 = mysqli_fetch_array($sqlm1);
    	$nm1 = $datam1['max_c1'];
    	$jns1 = "MAX";
   }else{
   		$sqlm1 = mysqli_query($konek,"SELECT MIN(c1) as min_c1 FROM tbl_penilaian WHERE id_periode = '$idp'");
    	$datam1 = mysqli_fetch_array($sqlm1);
    	$nm1 = $datam1['max_c1'];
    	$jns1 = "MIN";
   }
//data max min 
    //c2
   if ($jenis2 == "Benefit") {
   		$sqlm2 = mysqli_query($konek,"SELECT MAX(c2) as max_c2 FROM tbl_penilaian WHERE id_periode = '$idp'");
    	$datam2 = mysqli_fetch_array($sqlm2);
    	$nm2 = $datam2['max_c2'];
    	$jns2 = "MAX";
   }else{
   		$sqlm2 = mysqli_query($konek,"SELECT MIN(c2) as min_c2 FROM tbl_penilaian WHERE id_periode = '$idp'");
    	$datam2 = mysqli_fetch_array($sqlm2);
    	$nm2 = $datam2['max_c3'];
    	$jns2 = "MIN";
   }
//data max min 
    //c3
   if ($jenis3 == "Benefit") {
   		$sqlm3 = mysqli_query($konek,"SELECT MAX(c3) as max_c3 FROM tbl_penilaian WHERE id_periode = '$idp'");
    	$datam3 = mysqli_fetch_array($sqlm3);
    	$nm3 = $datam3['max_c3'];
    	$jns3 = "MAX";
   }else{
   		$sqlm3 = mysqli_query($konek,"SELECT MIN(c3) as min_c3 FROM tbl_penilaian WHERE id_periode = '$idp'");
    	$datam3 = mysqli_fetch_array($sqlm3);
    	$nm3 = $datam3['min_c3'];
    	$jns3 = "MIN";
   }
//data max min 
    //c4
   if ($jenis4 == "Benefit") {
   		$sqlm4 = mysqli_query($konek,"SELECT MAX(c4) as max_c4 FROM tbl_penilaian WHERE id_periode = '$idp'");
    	$datam4 = mysqli_fetch_array($sqlm4);
    	$nm4 = $datam4['max_c4'];	
    	$jns4 = "MAX";
   }else{
   		$sqlm4 = mysqli_query($konek,"SELECT MIN(c4) as min_c4 FROM tbl_penilaian WHERE id_periode = '$idp'");
    	$datam4 = mysqli_fetch_array($sqlm4);
    	$nm4 = $datam4['min_c4'];
    	$jns4 = "MIN";
   }
//data max min 
    //c5
   if ($jenis5 == "Benefit") {
   		$sqlm5 = mysqli_query($konek,"SELECT MAX(c5) as max_c5 FROM tbl_penilaian WHERE id_periode = '$idp'");
    	$datam5 = mysqli_fetch_array($sqlm5);
    	$nm5 = $datam5['max_c5'];	
    	$jns5 = "MAX";
   }else{
   		$sqlm5 = mysqli_query($konek,"SELECT MIN(c5) as min_c5 FROM tbl_penilaian WHERE id_periode = '$idp'");
    	$datam5 = mysqli_fetch_array($sqlm5);
    	$nm5 = $datam5['min_c5'];
    	$jns5 = "MIN";
   }
   //data max min 
    //c6
   if ($jenis6 == "Benefit") {
   		$sqlm6 = mysqli_query($konek,"SELECT MAX(c6) as max_c6 FROM tbl_penilaian WHERE id_periode = '$idp'");
    	$datam6 = mysqli_fetch_array($sqlm6);
    	$nm6 = $datam6['max_c6'];	
    	$jns6 = "MAX";
   }else{
   		$sqlm6 = mysqli_query($konek,"SELECT MIN(c6) as min_c6 FROM tbl_penilaian WHERE id_periode = '$idp'");
    	$datam6 = mysqli_fetch_array($sqlm6);
    	$nm6 = $datam6['min_c6'];
    	$jns6 = "MIN";
   }
?>
<div class="container-fluid">
	<div class="col-lg-12">
		<!-- Basic Card Example -->
		<div class="card shadow mt-3 mb-3">
			<div class="card-header py-3">
				<h6 class="m-0 font-weight-bold text-primary">Data Proses Perhitungan</h6>
			</div>
			<!-- Data 1 -->
			<div class="card-body">
				<h5>Data Nilai Bobot (W)</h5>
			<div class="table-responsive">
				<table class="table table-bordered">
					<thead>
						<tr align="center">
							<th><?php echo $k1; ?></th>
							<th><?php echo $k2; ?></th>
							<th><?php echo $k3; ?></th>
							<th><?php echo $k4; ?></th>
							<th><?php echo $k5; ?></th>
							<th><?php echo $k6; ?></th>
							
						</tr>
						<tr align="center">
							<th style="font-size: 15px;"><?php echo "($jenis1)";?></th>
							<th style="font-size: 15px;"><?php echo "($jenis2)"; ?></th>
							<th style="font-size: 15px;"><?php echo "($jenis3)"; ?></th>
							<th style="font-size: 15px;"><?php echo "($jenis4)"; ?></th>
							<th style="font-size: 15px;"><?php echo "($jenis5)"; ?></th>
							<th style="font-size: 15px;"><?php echo "($jenis6)"; ?></th>
							
						</tr>
					</thead>
					<tbody>

						
						<tr align="center">
							<td><?php echo number_format($b1,2); ?></td>
							<td><?php echo number_format($b2,2); ?></td>
							<td><?php echo number_format($b3,2); ?></td>
							<td><?php echo number_format($b4,2); ?></td>
							<td><?php echo number_format($b5,2); ?></td>
							<td><?php echo number_format($b6,2); ?></td>
							
						</tr>
					</tbody>
				</table>
			</div>
			</div>
			<!-- Data 2 -->
			<div class="card-body">
				<h5>Data Penilaian</h5>
			<div class="table-responsive">
				<table class="table table-bordered">
					<thead>
						<tr align="center">
							<th>No</th>
							<th>Nama Alternatif</th>
							<th><?php echo $k1; ?></th>
							<th><?php echo $k2; ?></th>
							<th><?php echo $k3; ?></th>
							<th><?php echo $k4; ?></th>
							<th><?php echo $k5; ?></th>
							<th><?php echo $k6; ?></th>
							
						</tr>
					</thead>
					<tbody>
						<?php 
							include ('../../config/koneksi.php');
							$no = 1;
							$qq = mysqli_query($konek, "SELECT * FROM tbl_penilaian a LEFT JOIN tbl_alternatif b ON a.id_alternatif=b.id_alternatif JOIN tbl_narapidana c ON b.id_narapidana = c.id_narapidana WHERE a.id_periode = '$idp' AND a.ket = 'B'");
							$rowq = mysqli_num_rows($qq);
							if ($rowq > 0) {
								while($dd = mysqli_fetch_assoc($qq)){
							?>
							<tr>
								<td align="right"><?php echo $no++; ?></td>
								<td><?php echo $dd['nama']; ?></td>
								<td><?php echo $dd['c1']; ?></td>
								<td><?php echo $dd['c2']; ?></td>
								<td><?php echo $dd['c3']; ?></td>
								<td><?php echo $dd['c4']; ?></td>
								<td><?php echo $dd['c5']; ?></td>
								<td><?php echo $dd['c6']; ?></td>
								
							</tr>
							<?php 
								}
								
							}else {
								?>
								<td colspan="7"><center><h3>Semua data penilaian sudah diproses.</h3></center></td>
								<?php  

							}
							?>
							
					</tbody>
				</table>
			</div>
			</div>
			<!-- Data 3 -->
			<div class="card-body">
				<h5>Data Nilai Max / Min</h5>
			<div class="table-responsive">
				<table class="table table-bordered">
					<thead>
						<tr align="center">
							<th><?php echo $k1; ?></th>
							<th><?php echo $k2; ?></th>
							<th><?php echo $k3; ?></th>
							<th><?php echo $k4; ?></th>
							<th><?php echo $k5; ?></th>
							<th><?php echo $k6; ?></th>
							
						</tr>
						<tr align="center">
							<th style="font-size: 10px;"><?php echo "($jenis1)"." ".$jns1; ?></th>
							<th style="font-size: 10px;"><?php echo "($jenis2)"." ".$jns2; ?></th>
							<th style="font-size: 10px;"><?php echo "($jenis3)"." ".$jns3; ?></th>
							<th style="font-size: 10px;"><?php echo "($jenis4)"." ".$jns4; ?></th>
							<th style="font-size: 10px;"><?php echo "($jenis5)"." ".$jns5; ?></th>
							<th style="font-size: 10px;"><?php echo "($jenis5)"." ".$jns6; ?></th>
							
						</tr>
					</thead>
					<tbody>

						
						<tr align="center">
							<td><?php echo number_format($nm1,2); ?></td>
							<td><?php echo number_format($nm2,2); ?></td>
							<td><?php echo number_format($nm3,2); ?></td>
							<td><?php echo number_format($nm4,2); ?></td>
							<td><?php echo number_format($nm5,2); ?></td>
							<td><?php echo number_format($nm6,2); ?></td>
							
						</tr>
						 <form action="" method="POST">
							<tr>
							<td colspan="9">
								<div align="right"><button type="submit" name="proses" class="btn btn-primary" >Proses</button>
							</div>
							
						</td>
					</tr>
				</form>	
			</tbody>
		</table>
		
	
			</div>
			</div>
		</div>
	</div>
</div>
<?php 
						if (isset($_POST['proses'])) {
							$sqlp1 = mysqli_query($konek,"SELECT * FROM tbl_penilaian WHERE id_periode = '$idp'");
							while ($row = mysqli_fetch_array($sqlp1)) {
								//tangkap data penilaian
								$ida = $row['id_alternatif'];
								$c1 = $row['c1'];
								$c2 = $row['c2'];
								$c3 = $row['c3'];
								$c4 = $row['c4'];
								$c5 = $row['c5'];
								$c5 = $row['c6'];
								
								//lakukan proses normalisasi
								//c1
								if ($jenis1 == "Benefit") {	
									$c1 = $c1 / $nm1;
								}else{
									$c1 = $nm1 / $c1;
								}
								//c2
								if ($jenis2 == "Benefit") {	
									$c2 = $c2 / $nm2;
								}else{
									$c2 = $nm2 / $c2;
								}
								//c3
								if ($jenis3 == "Benefit") {	
									$c3 = $c3 / $nm3;
								}else{
									$c3 = $nm3 / $c3;
								}
								//c4
								if ($jenis4 == "Benefit") {	
									$c4 = $c4 / $nm4;
								}else{
									$c4 = $nm4 / $c4;
								}
								//c5
								if ($jenis5 == "Benefit") {	
									$c5 = $c5 / $nm5;
								}else{
									$c5 = $nm5 / $c5;
								}
								//c6
								if ($jenis6 == "Benefit") {	
									$c6 = $c6 / $nm6;
								}else{
									$c6 = $nm6 / $c6;
								}
								
								//pencarian hasil
								$nilai_akhir = ($c1 * $b1) + ($c2 * $b2) + ($c3 * $b3) + ($c4 * $b4) + ($c5 * $b5) + ($c6 * $b6); 
								//simpan normalisasi
								$sqlsimpans = mysqli_query($konek,"INSERT INTO tbl_normalisasi VALUES ('','$ida','$idp','$c1','$c2','$c3','$c4','$c5','$c6')");
								//simpan pencarian hasil
							
								$sqlsimpans2 = mysqli_query($konek,"INSERT INTO tbl_hasil VALUES ('','$ida','$idp','$nilai_akhir')");
								$sqlupdateket = $konek->query("UPDATE tbl_penilaian SET ket ='S' WHERE id_alternatif = '$ida' AND id_periode = '$idp'");
							}
							 if (($sqlsimpans)&&($sqlsimpans2)){
							 	  echo "<script language=javascript>
          							window.alert('Berhasil Menambah!');
          							window.location='hasil_keputusan.php?idp=$idp';
          							</script>";
      							}else{
        							echo "<script language=javascript>
         									 window.alert('Gagal Menambah!');
         									 window.location='hasil_keputusan.php?idp=$idp';
          								</script>";
     								}
							 }
							
						 ?>
<?php 
	include ("style/footer.php");
?>