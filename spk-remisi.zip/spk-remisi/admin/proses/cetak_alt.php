<?php 
  include("../../config/koneksi.php");
  $idp = $_GET['idp'];
  $sql = mysqli_query($konek,"SELECT * FROM tbl_periode WHERE id_periode = '$idp'");
  $data = mysqli_fetch_array($sql);
?>
<link rel="stylesheet" type="text/css" href="style/css/bootstrap.css">
<title>Laporan Alternatif</title>
<body>
<center>
	<div class="container">
<p><img src="style/logo1.jpg" width="120px" class="mt-3"></p>
<p style="font-size:25px;padding:0px;margin-bottom:-15px;"><b>MENTERI HUKUM DAN HAK ASASI MANUSIA REPUBLIK INDONESIA</b></p>
<p class="mt-3" style="font-size:30px;padding:0px;margin-bottom:-15px;">LAPAS KELAS II B KOTA MUARO SINJUNJUNG</p>
<p class="mt-3" style="font-size:18px;padding:0px;margin-bottom:-12px;">Jl. Pengayoman, Muaro Sijunjung</p>
<br>
<hr>
<br>
</center>
  <?php 
	$no = 1;
	$q = mysqli_query($konek,"SELECT * FROM  tbl_alternatif a LEFT JOIN tbl_narapidana b ON a.id_narapidana = b.id_narapidana WHERE id_periode = '$idp'");
?>
<div class="container-fluid">
	<h3 align="center">DATA ALTERNATIF <br><?php echo $data['keterangan']; ?></h3>
	<table width="100%" style="text-align: left; border-collapse: collapse; " border="1" class="table table-bordered" >
		<tr>
			<thead class="bg-success">
			<th>No</th>
			<th>Nama Alternatif</th>
			<th>Jenis Kelamin</th>
			<th>Tanggal Lahir</th>
			<th>Alamat</th>
			<th>Perkara Pidana</th>
			<th>Agama</th>
		</thead>
		</tr>
		<?php 
		$no = 1;
		while ($row = mysqli_fetch_array($q)) {
			?>
		<tr>
			<td><?php echo $no; ?></td>
			<td><?php echo $row["nama"]; ?></td>
			<td><?php echo $row["jenis_kelamin"]; ?></td>
			<td><?php echo $row["tgl_lahir"]; ?></td>
			<td><?php echo $row["alamat"]; ?></td>
			<td><?php echo $row["perkara"]; ?></td>
			<td><?php echo $row["agama"]; ?></td>
		</tr>
		<?php	
		$no++;
		}
		 ?>
	</table>
</div>
<h4 style="margin-left: 70%;">Sijunjung, <?php echo date('d F Y') ?></h4>
<p style="margin-left: 70%;">A.n MENTERI HUKUM DAN HAM RI <br> DIREKTUR JENDERAL PEMASYARAKATAN.</p>
<div style="
	margin-left: 70%;
  border: 5px solid blue;
  padding-top: 10px;
  padding-right: 10px;
  padding-bottom: 10px;
  padding-left: 10px;
">
<p><img src="style/logo1.jpg" width="100px">Ditandatangin Secara Elektronik Oleh
<b style="margin-left: 27%;">Reynhard Sitilonga</b></p>
<p style="margin-left: 27%;">NIP : 670903320000001000</p>
</h4>
</div>
</center>

</body>

<script type="text/javascript" src="style/js/bootstrap.js"></script>