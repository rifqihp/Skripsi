<?php 
	include ("style/header.php");
	include ("style/sidebarawal.php");
	  // $idp = $_GET['idp'];
?>
<div class="container-fluid">
	<div class="col-lg-12">
		<!-- Basic Card Example -->
		<div class="card shadow mt-3 mb-3">
				<form method="get" action="data_kriteria.php">
						<label>Cari :</label>
						<input type="text" name="cari">
						<input type="submit" value="Cari">
				</form>
				<?php 
				if(isset($_GET['cari'])){
					$cari = $_GET['cari'];
					echo "<b>Hasil pencarian : ".$cari."</b>";
				}
				?>
				<?php 
				if(isset($_GET['cari'])){
		$cari = $_GET['cari'];
		$data = mysqli_query($konek,"select * from tbl_subkriteria where nama_kriteria like '%".$cari."%'");				
	} else {
		$data = mysqli_query($konek,"select * from tbl_subkriteria");		
	}
	?>
 
			<div class="card-header py-3">
				<h6 class="m-0 font-weight-bold text-primary">Data Sub Kriteria</h6>
			</div>
			<div class="card-body">
				<button class="btn btn-sm btn-primary mb-3" data-toggle="modal" data-target="#tambah_bank"><i class="fas fa-plus fa-sm"></i> Tambah Kriteria</button>
        <div class="table-responsive">
				<table class="table table-bordered">
					<thead>
						<tr align="center">
							<th>No</th>
							<th>Nama Kriteria</th>
							<th>Keterangan</th>
							<th>Nilai Bobot</th>
							<th colspan="2">Aksi</th>
						</tr>
					</thead>
					<?php 
						include("../config/koneksi.php");
						$no=1;
						$sql = mysqli_query($konek, "SELECT * FROM tbl_subkriteria a LEFT JOIN tbl_kriteria b ON a.id_kriteria = b.id_kriteria");
						while($array = mysqli_fetch_assoc($sql)){
					?>
					<tbody>
						<tr>
							<td><?php echo $no++; ?></td>
							<td><?php echo $array['nama_kriteria']; ?></td>
							<td><?php echo $array['ket']; ?></td>
							<td><?php echo $array['nbobot']; ?></td>
							<td>
								<a href="edit_subkriteria.php?id=<?php echo $array['id_subkriteria']; ?>"><i class="btn btn-success btn-sm"><span class="fas fa-edit"></span></i></a></td>

							<td>
								<a href="hapus_subkriteria.php?id=<?php echo $array['id_subkriteria']; ?>"><i class="btn btn-danger btn-sm"><span class="fas fa-trash"></span></i></a></td>
						</tr>
					</tbody>
					<?php 
					} 
					?>
				</table>
      </div>
			<!-- <div align="right">
	<a href="data_alternatif.php?&idp=<?php echo $idp; ?>" class="btn btn-danger">Back</a>
	<a href="data_penilaian.php?&idp=<?php echo $idp; ?>" class="btn btn-primary">Next</a>
</div> -->
			</div>
</div>
		</div>
	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="tambah_bank" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Form Entry Data Sub Kriteria</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      	<form action="" method="POST" enctype="multipart/form-data">
      		<div class="form-group">
      			<!-- <input type="hidden" class="form-control mb-2" name="id" value="<?php echo $_SESSION['id']; ?>"> -->
                <label for="sub kriteria">Nama Kriteria</label>
                <select name="id_kriteria" id="" class="form-control">
                    <option>--Pilih Kriteria</option>
                <?php 
                    include("../config/koneksi.php");
                      $sqlkriteria = mysqli_query($konek,"SELECT * FROM tbl_kriteria");
                      while ($row = mysqli_fetch_array($sqlkriteria)) {
                        ?>
                        <option value="<?php echo $row['id_kriteria'] ?>"><?php echo $row['nama_kriteria']; ?></option>
                        <?php
                      }
                       ?>
                    </select>
               
                <label>Keterangan</label>
      			<input type="text" class="form-control mb-2" name="ket" placeholder="Sub Kriteria" required="">
            
                <label>Nilai Bobot</label>
      			<input type="text" name="nbobot" class="form-control mb-2" placeholder="Nilai Bobot">
      		</div>
      </div>
      <div class="modal-footer">
        <button type="submit" name="tambah" class="btn btn-primary btn-sm">Tambah</button>
      </div>
      	</form>
    </div>
  </div>
</div>


<?php 
	include ("../config/koneksi.php");
	if (isset($_POST['tambah'])) {
        $query2 = mysqli_query($konek,"SELECT * FROM tbl_subkriteria ORDER BY id_subkriteria DESC");
        $data2 = mysqli_fetch_assoc($query2);
        $jml = mysqli_num_rows($query2);
        if($jml==0){
          $idk='S001';
          }else{
            $subid = substr($data2['id_subkriteria'],3);
            if($subid>0 && $subid<=8){
              $sub = $subid+1;
              $idk='S00'.$sub;
            }elseif($subid>=9 && $subid<=100){
              $sub = $subid+1;
              $idk='S0'.$sub;
            }elseif($subid>=99 && $subid<=1000){
              $sub = $subid+1;
              $idk='S'.$sub;
            }
          }
          $id_kriteria = $_POST['id_kriteria'];
          $ket = $_POST['ket'];
          $nbobot = $_POST['nbobot'];
          $save = mysqli_query($konek,"INSERT INTO tbl_subkriteria VALUES ('$idk','$id_kriteria','$ket','$nbobot')");

	if($save) {
      echo "<script language=javascript>
          window.alert('Berhasil Menambah!');
          window.location='sub_kriteria.php';
          </script>";
      }else{
        echo "<script language=javascript>
          window.alert('Gagal Menambah!');
          window.location='sub_kriteria.php';
          </script>";
      }
}
?>

<?php 
	include ("style/footer.php");
?>