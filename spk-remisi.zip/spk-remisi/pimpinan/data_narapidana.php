<?php 
	include ("style/header.php");
	include ("style/sidebarawal.php");
      // $idp = $_GET['idp'];
?>
<div class="container-fluid">
	<div class="col-lg-12">
		<!-- Basic Card Example -->
		<div class="card shadow mt-3 mb-3">
			<div class="card-header py-3">
				<h6 class="m-0 font-weight-bold text-success">Data Narapidana</h6>
			</div>
			<div class="card-body">
				<!-- <button class="btn btn-sm btn-primary mb-3" data-toggle="modal" data-target="#tambah_mobil"><i class="fas fa-plus fa-sm"></i> Tambah Data</button> -->
        <a target="_blank" href="cetak_narapidana.php" class="btn btn-sm btn-success mb-3"><i class="fas fa-print"></i> Cetak</a>
      <div class="table-responsive">
				<table class="table table-bordered">
					<thead>
						<tr align="center">
							<th>No</th>
							<!-- <th>ID Narapidana</th> -->
							<th>Nama Narapidana</th>
              				<th>Tanggal Lahir</th>
              				<th>Jenis Kelamin</th>
							<th>Alamat</th>
							<th>Agama</th>
							<th>Perkara</th>
							<th>Tanggal Masuk</th>
							<th>Tanggal Keluar</th>
							<th>Hukuman</th>  
							<!-- <th colspan="2">Aksi</th> -->
						</tr>
					</thead>
					<?php 
						include("../config/koneksi.php");
						$no=1;
						$sql = mysqli_query($konek, "SELECT * FROM tbl_narapidana ");
						while($array = mysqli_fetch_assoc($sql)){
					?>
					<tbody>
						<tr>
							<td><?php echo $no++; ?></td>
							
							<td><?php echo $array['nama']; ?></td>
							<td><?php echo $array['tgl_lahir']; ?></td>
							<td><?php echo $array['jenis_kelamin']; ?></td>
              				<td><?php echo $array['alamat']; ?></td>
							<td><?php echo $array['agama']; ?></td>
							<td><?php echo $array['perkara']; ?></td>
							<td><?php echo $array['tgl_masuk']; ?></td>
							<td><?php echo $array['tgl_keluar']; ?></td>
							<td><?php echo $array['hukuman']; ?></td>
              
							<!-- <td>
								<a href="edit_narapidana.php?id=<?php echo $array['id_narapidana']; ?>"><i class="btn btn-success btn-sm"><span class="fas fa-edit"></span></i></a>
							</td>

							<td>
								<a href="hapus_narapidana.php?id=<?php echo $array['id_narapidana']; ?>"><i class="btn btn-danger btn-sm"><span class="fas fa-trash"></span></i></a>
							</td> -->
						</tr>
					</tbody>
					<?php 
					} 
					?>
				</table>
      </div>
			</div>
		</div>
	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="tambah_mobil" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Form Entry Data Narapidana</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      	<form action="" method="POST" enctype="multipart/form-data">
      		<div class="form-group">
           
            <label>Nama Narapidana</label>
      			<input type="text" class="form-control mb-2" name="nama" placeholder="Nama Narapidana" required="">

      			<label>Tanggal Lahir</label>
            <input type="date" class="form-control mb-2" name="tgl_lahir" required="">

            <label>Jenis Kelamin</label>
            <select class="form-control" name="jenis">
            	<option>--Jenis Kelamin--</option>
            	<option value="Laki-laki">Laki-laki</option>
            	<option value="Perempuan">Perempuan</option>
            </select>

           	<label>Alamat</label>
            <textarea class="form-control mb-2" name="alamat" placeholder="Alamat" required=""></textarea>
            
            <label>Agama</label>
            <select class="form-control mb-2" name="agama">
              <option>--Agama--</option>
              <option value="Islam">Islam</option>
              <option value="Protestan">Protestan</option>
              <option value="Katolik">Katolik</option>
              <option value="Hindu">Hindu</option>
              <option value="Buddha">Buddha</option>
              <option value="Khonghucu">Khonghucu</option>
            </select>
            
            <label>Perkara</label>
            <input type="text" class="form-control mb-2" name="perkara" required="">
            
            <label>Tanggal Masuk</label>
            <input type="date" class="form-control mb-2" name="tgl_masuk" required="">

            <label>Tanggal Keluar</label>
            <input type="date" class="form-control mb-2" name="tgl_keluar" required="">
            
            <label>Hukuman</label>
            <input type="text" class="form-control mb-2" name="hukuman" required="">
           
      		</div>
      </div>
      <div class="modal-footer">
        <button type="submit" name="tambah" class="btn btn-primary btn-sm">Tambah</button>
      </div>
      	</form>
    </div>
  </div>
</div>


<?php 
	include ("../config/koneksi.php");
	if (isset($_POST['tambah'])) {
      
      $nama 		    = $_POST['nama'];
      $tgl_lahir 		= $_POST['tgl_lahir'];
      $jenis 				= $_POST['jenis'];
      $alamat 			= $_POST['alamat'];
      $agama     		= $_POST['agama'];
      $perkara     	= $_POST['perkara'];
      $tgl_masuk    = $_POST['tgl_masuk'];
      $tgl_keluar   = $_POST['tgl_keluar'];
      $hukuman     	= $_POST['hukuman'];
      
	
	$save = mysqli_query($konek,"INSERT INTO tbl_narapidana VALUES('','$nama','$tgl_lahir','$jenis','$alamat','$agama','$perkara','$tgl_masuk','$tgl_keluar','$hukuman')");

	if($save) {
      echo "<script language=javascript>
          window.alert('Berhasil Menambah!');
          window.location='data_narapidana.php';
          </script>";
      }else{
        echo "<script language=javascript>
          window.alert('Gagal Menambah!');
          window.location='data_narapidana.php';
          </script>";
      }
}
?>

<?php 
	include ("style/footer.php");
?>