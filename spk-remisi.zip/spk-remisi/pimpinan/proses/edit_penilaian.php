<?php 
    include ('style/header.php');
    include ('style/sidebar.php');
	include("../../config/koneksi.php");
	$ids = $_GET['id'];
	$sqlcek = mysqli_query($konek,"SELECT * FROM tbl_alternatif a join tbl_narapidana b on a.id_narapidana = b.id_narapidana WHERE id_alternatif = '$ids'");
	$data = mysqli_fetch_array($sqlcek);
	//kriteria1
	$sqlc1 = mysqli_query($konek,"SELECT nama_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT001'");
    $data1 = mysqli_fetch_array($sqlc1);
    $k1 = $data1[0];
    //kriteria2
    $sqlc2 = mysqli_query($konek,"SELECT nama_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT002'");
    $data2 = mysqli_fetch_array($sqlc2);
    $k2 = $data2[0];
    //kriteria3
    $sqlc3 = mysqli_query($konek,"SELECT nama_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT003'");
    $data3 = mysqli_fetch_array($sqlc3);
    $k3 = $data3[0];
    //kriteria4
    $sqlc4 = mysqli_query($konek,"SELECT nama_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT004'");
    $data4 = mysqli_fetch_array($sqlc4);
    $k4 = $data4[0];
    $sqlc5 = mysqli_query($konek,"SELECT nama_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT005'");
    $data5 = mysqli_fetch_array($sqlc5);
    $k5 = $data5[0];
    //kriteria6
    $sqlc6 = mysqli_query($konek,"SELECT nama_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT006'");
    $data6 = mysqli_fetch_array($sqlc6);
    $k6 = $data6[0];
    //kriteria7
    $sqlc7 = mysqli_query($konek,"SELECT nama_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT007'");
    $data7 = mysqli_fetch_array($sqlc7);
    $k7 = $data1[0];
?>
<div class="container-fluid">
	<!-- Basic Card Example -->
	<div class="card shadow mt-3 mb-3">
		<div class="card-header py-3">
			<h6 class="m-0 font-weight-bold text-primary">Edit Data Penilaian <?php echo $data['nama']; ?></h6>
		</div>
		<div class="card-body">
		<?php 
			$query = mysqli_query($konek,"SELECT * FROM tbl_penilaian where id_alternatif='$ids'")or die(mysqli_error());
			while($data = mysqli_fetch_array($query)){
		?>
		<form action="" method="POST" enctype="multipart/form-data">
			<input type="hidden" name="ids" value="<?php echo $ids; ?>">
			<div class="form-group">
              <input type="hidden" name="ids" value="<?php echo $ids; ?>">
      				<!-- C1 -->
      			<label><?php echo $k1; ?> (C1)</label>
            <select name="c1" class="form-control mb-2">
              <option value="">Pilih Nilai</option>
              <option value="1">Sangat Baik</option>
              <option value="0.8">Baik</option>
              <option value="0.6">Cukup Baik</option>
              <option value="0.4">Kurang Baik</option>
              <option value="0.2">Tidak Baik</option>
            </select>
            <!-- C2 -->
            <label><?php echo $k2; ?> (C2)</label>
            <select name="c2" class="form-control mb-2">
              <option value="">Pilih Nilai</option>
              <option value="1">Sangat Baik</option>
              <option value="0.8">Baik</option>
              <option value="0.6">Cukup Baik</option>
              <option value="0.4">Kurang Baik</option>
              <option value="0.2">Tidak Baik</option>
            </select>
            <!-- C3 -->
            <label><?php echo $k3; ?> (C3)</label>
            <select name="c3" class="form-control mb-2">
              <option value="">Pilih Nilai</option>
              <option value="1">Sangat Baik</option>
              <option value="0.8">Baik</option>
              <option value="0.6">Cukup Baik</option>
              <option value="0.4">Kurang Baik</option>
              <option value="0.2">Tidak Baik</option>
            </select>
            <!-- C4 -->
            <label><?php echo $k4; ?> (C4)</label>
            <select name="c4" class="form-control mb-2">
              <option value="">Pilih Nilai</option>
              <option value="1">Sangat Baik</option>
              <option value="0.8">Baik</option>
              <option value="0.6">Cukup Baik</option>
              <option value="0.4">Kurang Baik</option>
              <option value="0.2">Tidak Baik</option>
            </select>
            <!-- C5 -->
            <label><?php echo $k5; ?> (C5)</label>
            <select name="c5" class="form-control mb-2">
              <option value="">Pilih Nilai</option>
              <option value="1">Sangat Baik</option>
              <option value="0.8">Baik</option>
              <option value="0.6">Cukup Baik</option>
              <option value="0.4">Kurang Baik</option>
              <option value="0.2">Tidak Baik</option>
            </select>
            
      		</div>
      	</div>
      	<div class="modal-footer">
      		<button type="submit" name="edit" class="btn btn-success btn-sm" >Edit</button>
      	</div>
		</form>
		<?php 
		}
		?>
	</div>
</div>

<?php
include ("../../config/koneksi.php");

if(isset($_POST['edit'])) {

$ids 				= $_POST['ids'];
$c1 				= $_POST['c1'];
$c2 				= $_POST['c2'];
$c3 				= $_POST['c3'];
$c4 				= $_POST['c4'];
$c5 				= $_POST['c5'];

$sqlcekproses = $konek->query("SELECT * FROM tbl_hasil WHERE id_periode = '$idp'");
$rowcekproses = $sqlcekproses->num_rows;
if ($rowcekproses > 0) {
  $sqledit = mysqli_query($konek,"UPDATE tbl_penilaian SET id_alternatif='$ids', c1='$c1', c2='$c2', c3='$c3', c4='$c4', c5='$c5' WHERE id_alternatif='$ids'"); // Eksekusi/ Jalankan query dari variabel $query
  if ($sqledit) {
    $deletenor = $konek->query("DELETE FROM tbl_normalisasi WHERE id_periode = '$idp'");
    $deletehasil = $konek->query("DELETE FROM tbl_hasil WHERE id_periode = '$idp'");
    if ($deletenor && $deletehasil) {
      include 'function_proses.php';
    }else{
       echo "<script language=javascript>
               window.alert('Ada kesalahan pada proses hapus data!');
               window.location='data_penilaian.php?idp=$idp';
               </script>";
    }

  }else{
     echo "<script language=javascript>
               window.alert('Ada kesalahan pada proses edit!');
               window.location='data_penilaian.php?idp=$idp';
               </script>";
  }
}else{
   $sqledit = mysqli_query($konek,"UPDATE tbl_penilaian SET id_alternatif='$ids', c1='$c1', c2='$c2', c3='$c3', c4='$c4', c5='$c5' WHERE id_alternatif='$ids'"); // Eksekusi/ Jalankan query dari 
   if ($sqledit) {
     echo "<script language=javascript>
               window.alert('Data Berhasil Diedit!');
               window.location='data_penilaian.php?idp=$idp';
               </script>";
   }else{
    echo "<script language=javascript>
               window.alert('Data Gagal Diedit!');
               window.location='data_penilaian.php?idp=$idp';
               </script>";
   }
}
}
?>

<?php 
    include ('style/footer.php');
?>