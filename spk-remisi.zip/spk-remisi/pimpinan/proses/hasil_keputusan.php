<?php 
	include ("style/header.php");
	include ("style/sidebar.php");
	include '../../config/koneksi.php';
	$idp = $_GET['idp'];
	//kriteria1
	$sqlc1 = mysqli_query($konek,"SELECT nama_kriteria,bobot,jenis_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT001'");
    $data1 = mysqli_fetch_array($sqlc1);
    $jenis1 = $data1['jenis_kriteria'];
    $k1 = $data1[0];
    $b1 = $data1[1];
    //kriteria2
    $sqlc2 = mysqli_query($konek,"SELECT nama_kriteria,bobot,jenis_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT002'");
    $data2 = mysqli_fetch_array($sqlc2);
    $jenis2 = $data2['jenis_kriteria'];
    $k2 = $data2[0];
    $b2 = $data2[1];
    //kriteria3
    $sqlc3 = mysqli_query($konek,"SELECT nama_kriteria,bobot,jenis_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT003'");
    $data3 = mysqli_fetch_array($sqlc3);
    $jenis3 = $data3['jenis_kriteria'];
    $k3 = $data3[0];
    $b3 = $data3[1];
    //kriteria4
    $sqlc4 = mysqli_query($konek,"SELECT nama_kriteria,bobot,jenis_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT004'");
    $data4 = mysqli_fetch_array($sqlc4);
    $jenis4 = $data4['jenis_kriteria'];
    $k4 = $data4[0];
    $b4 = $data4[1];
    //kriteria5
    $sqlc5 = mysqli_query($konek,"SELECT nama_kriteria,bobot,jenis_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT005'");
    $data5 = mysqli_fetch_array($sqlc5);
    $jenis5 = $data5['jenis_kriteria'];
    $k5 = $data5[0];
    $b5 = $data5[1];
    
    ?>
<div class="container-fluid">
	<div class="col-lg-12">
		<!-- Basic Card Example -->
		<div class="card shadow mt-3 mb-3">
			<div class="card-header py-3">
				<h6 class="m-0 font-weight-bold text-success">Data Hasil Proses Perhitungan</h6>
			</div>
			<div class="card-body">
				<h5>Data Hasil Perhitungan Normalisasi</h5>
			<div class="table-responsive">
				<table class="table table-bordered">
					<thead>
						<tr align="center">
							<th style="font-size: 13px;">No</th>
							<th style="font-size: 13px;">Nama Alternatif</th>
							<th style="font-size: 13px;"><?php echo $k1; ?></th>
							<th style="font-size: 13px;"><?php echo $k2; ?></th>
							<th style="font-size: 13px;"><?php echo $k3; ?></th>
							<th style="font-size: 13px;"><?php echo $k4; ?></th>
							<th style="font-size: 13px;"><?php echo $k5; ?></th>
							
					</thead>
					<tbody>
						<?php 
							include ('../../config/koneksi.php');
							$no = 1;
							$qq = mysqli_query($konek, "SELECT * FROM tbl_normalisasi a LEFT JOIN tbl_alternatif b ON a.id_alternatif=b.id_alternatif JOIN tbl_narapidana c ON b.id_narapidana = c.id_narapidana WHERE a.id_periode = '$idp'");
							while($dd = mysqli_fetch_assoc($qq)){
						?>
						<tr>
							<td align="right" style="font-size: 13px;"><?php echo $no++; ?></td>
							<td style="font-size: 13px; text-align: center"><?php echo $dd['nama']; ?></td>
							<td style="font-size: 13px; text-align: center"><?php echo number_format($dd['c1'],2); ?></td>
							<td style="font-size: 13px; text-align: center"><?php echo number_format($dd['c2'],2); ?></td>
							<td style="font-size: 13px; text-align: center"><?php echo number_format($dd['c3'],2); ?></td>
							<td style="font-size: 13px; text-align: center"><?php echo number_format($dd['c4'],2); ?></td>
							<td style="font-size: 13px; text-align: center"><?php echo number_format($dd['c5'],2); ?></td>
							
						</tr>
						<?php 
							}
						?>
					</tbody>
				</table>
			</div>
			</div>
			<!-- Data 2 -->
			<div class="card-body">
				<h5>Data Hasil Perankingan</h5>
			<div class="table-responsive">
				<table class="table table-bordered">
					<thead>
						<tr align="center">
							<th style="font-size: 13px;">No</th>
							<th style="font-size: 13px;">Nama Alternatif</th>
							<th style="font-size: 13px;">Nilai Preferensi (V)</th>
							<th style="font-size: 13px;">Ranking</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							include ('../../config/koneksi.php');
							$noo = 1;
							$qq = mysqli_query($konek, "SELECT * FROM tbl_hasil a LEFT JOIN tbl_alternatif b ON a.id_alternatif=b.id_alternatif JOIN tbl_narapidana c ON b.id_narapidana = c.id_narapidana WHERE a.id_periode = '$idp' ORDER BY a.nilai_preferensi DESC");
							while($dd = mysqli_fetch_assoc($qq)){
						?>
						<tr>
							<td align="right" style="font-size: 13px; text-align: center"><?php echo $noo; ?></td>
							<td style="font-size: 13px; text-align: center"><?php echo $dd['nama']; ?></td>
							<td style="font-size: 13px; text-align: center"><?php echo $dd['nilai_preferensi']; ?></td>
							<td style="font-size: 13px; text-align: center"><?php echo $noo; ?></td>
						</tr>
						<?php 
						$noo++;
							}
						?>
					</tbody>
				</table>
			</div>
			</div>
			<?php 
			$sqlrank = mysqli_query($konek,"SELECT *  FROM tbl_hasil a LEFT JOIN tbl_alternatif b on a.id_alternatif = b.id_alternatif JOIN tbl_narapidana c ON b.id_narapidana = c.id_narapidana WHERE a.id_periode = '$idp' ORDER BY a.nilai_preferensi DESC LIMIT 1");
			$rank = mysqli_fetch_array($sqlrank);
			 ?>
			<div class="card shadow mt-3 mb-3">
			<div class="card-header py-3">
				<h6 class="m-0 font-weight-bold text-primary">Data Hasil Kesimpulan</h6>
			</div>
			<div class="card-body">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th colspan="6"><label style="font-size: 15px;"><i style="color : red;">* Nilai standar untuk mendapatkan remisi adalah 0.70</i></th>
						</tr>
						<tr align="center">
							<th style="font-size: 13px;">No</th>
							<th style="font-size: 13px;">Nama Alternatif</th>
							<th style="font-size: 13px;">Jenis Kelamin</th>
							<th style="font-size: 13px;">Tanggal Lahir</th>
							<th style="font-size: 13px;">Alamat</th>
							
						</tr>
					</thead>
					<tbody>
						<?php 
							include ('../../config/koneksi.php');
							$noo1 = 1;
							$qq = mysqli_query($konek, "SELECT * FROM tbl_hasil a LEFT JOIN tbl_alternatif b ON a.id_alternatif=b.id_alternatif JOIN tbl_narapidana c ON b.id_narapidana = c.id_narapidana WHERE a.id_periode = '$idp' AND a.nilai_preferensi >= 0.70 ORDER BY a.nilai_preferensi DESC");
							while($dd = mysqli_fetch_assoc($qq)){
							?>
							<tr>
							<td align="right" style="font-size: 13px; text-align: center"><?php echo $noo1; ?></td>
							<td style="font-size: 13px; text-align: center"><?php echo $dd['nama']; ?></td>
							<td style="font-size: 13px; text-align: center"><?php echo $dd['jenis_kelamin']; ?></td>
							<td style="font-size: 13px; text-align: center"><?php echo $dd['tgl_lahir']; ?></td>
							<td style="font-size: 13px; text-align: center"><?php echo $dd['alamat']; ?></td>
							
						</tr>
							<?php	
							}
						?>
						<tr>
							<td colspan="6"><a target="_blank" class="btn btn-sm btn-success mb-3" href="cetak_hasil.php?idp=<?php echo $idp; ?>"><i class="fas fa-print"></i> Cetak</a></td>
						</tr>
					</tbody>
				</table>
				
			</div>
			</div>
		</div>
	</div>
</div>


<!-- MODAL TAMBAH -->
<!-- Button trigger modal -->

<!-- TUTUP MODAL TAMBAH -->
<?php 
	include ("style/footer.php");
?>