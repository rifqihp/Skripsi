<?php 
    include ('style/header.php');
    include ('style/sidebar.php');
	include("../../config/koneksi.php");
	$id_alternatif = $_GET['id'];
	$idp = $_GET['idp'];
?>
<div class="container-fluid">
	<!-- Basic Card Example -->
	<div class="card shadow mt-3 mb-3">
		<div class="card-header py-3">
			<h6 class="m-0 font-weight-bold text-primary">Data Alternatif</h6>
		</div>
		<div class="card-body">
		<?php 
			$query = mysqli_query($konek,"SELECT * FROM tbl_alternatif where id_alternatif='$id_alternatif'")or die(mysqli_error());
			while($data = mysqli_fetch_array($query)){
		?>
		<form action="" method="POST" enctype="multipart/form-data">
			<div class="form-group">
				<label>Nama Alternatif</label>
      			<input type="text" class="form-control mb-2" name="nama" value="<?php echo $data['nama_alternatif']; ?>">
      			<label>Jenis Kelamin</label>
      			<input type="text" class="form-control mb-2" name="jk" value="<?php echo $data['jenis_kelamin']; ?>">
      			<label>Tanggal Lahir</label>
      			<input type="text" class="form-control mb-2" name="tgl_lahir" value="<?php echo $data['tgl_lahir']; ?>">
      			<label>Alamat</label>
      			<textarea class="form-control mb-2" name="alamat"><?php echo $data['alamat'] ?></textarea>
      			
      		</div>
      	</div>
      	<div class="modal-footer">
      		<button type="submit" name="edit" class="btn btn-success btn-sm" >Edit</button>
      	</div>
		</form>
		<?php 
		}
		?>
	</div>
</div>

<?php
include ("../../config/koneksi.php");
if(isset($_POST['edit'])) {
$nama 					= $_POST['nama'];
$jk 					= $_POST['jk'];
$tgl_lahir 				= $_POST['tgl_lahir'];
$alamat 				= $_POST['alamat'];

	$sql3 = mysqli_query($konek,"UPDATE tbl_alternatif SET nama_alternatif = '$nama', jenis_kelamin ='$jk', tgl_lahir='$tgl_lahir' , alamat ='$alamat' WHERE id_alternatif ='$id_alternatif'"); // Eksekusi/ Jalankan query dari variabel $query

	if($sql3){ // Cek jika proses simpan ke database sukses atau tidak
		// Jika Sukses, Lakukan :
		
		echo "<script language=javascript>
				window.alert('Berhasil Mengedit!');
				window.location='data_alternatif.php?idp=$idp';
				</script>"; // Redirect ke halaman datamobil.php
	}else{
		// Jika Gagal, Lakukan :
		echo "<script language=javascript>
				window.alert('Gagal Mengedit!');
				window.location='data_alternatif.php?idp=$idp';
				</script>";
	}
}
?>

<?php 
    include ('style/footer.php');
?>