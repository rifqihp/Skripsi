<?php 
  include("../../config/koneksi.php");
   $sqlc1 = mysqli_query($konek,"SELECT nama_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT001'");
    $data1 = mysqli_fetch_array($sqlc1);
    $k1 = $data1[0];
    //kriteria2
    $sqlc2 = mysqli_query($konek,"SELECT nama_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT002'");
    $data2 = mysqli_fetch_array($sqlc2);
    $k2 = $data2[0];
    //kriteria3
    $sqlc3 = mysqli_query($konek,"SELECT nama_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT003'");
    $data3 = mysqli_fetch_array($sqlc3);
    $k3 = $data3[0];
    //kriteria4
    $sqlc4 = mysqli_query($konek,"SELECT nama_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT004'");
    $data4 = mysqli_fetch_array($sqlc4);
    $k4 = $data4[0];
    $sqlc5 = mysqli_query($konek,"SELECT nama_kriteria FROM tbl_kriteria WHERE id_kriteria = 'KRT005'");
    $data5 = mysqli_fetch_array($sqlc5);
    $k5 = $data5[0];
    
  $idp = $_GET['idp'];
  $sql = mysqli_query($konek,"SELECT * FROM tbl_periode WHERE id_periode = '$idp'");
  $data = mysqli_fetch_array($sql);
?>
<title>Data Penilaian</title>
<body onload="window.print();">
	<link rel="stylesheet" type="text/css" href="style/css/bootstrap.css">
<center>
<div class="container">
<p><img src="style/logo1.jpg" width="120px" class="mt-3"></p>
<p style="font-size:25px;padding:0px;margin-bottom:-15px;"><b>MENTERI HUKUM DAN HAK ASASI MANUSIA REPUBLIK INDONESIA</b></p>
<p class="mt-3" style="font-size:30px;padding:0px;margin-bottom:-15px;">LAPAS KELAS II B KOTA MUARO SINJUNJUNG</p>
<p class="mt-3" style="font-size:18px;padding:0px;margin-bottom:-12px;">Jl. Pengayoman, Muaro Sijunjung</p>
<br>
<hr>
<br>
</center>
  <?php 
	$no = 1;
	$q = mysqli_query($konek,"SELECT * FROM tbl_penilaian a LEFT JOIN tbl_alternatif b ON a.id_alternatif = b.id_alternatif JOIN tbl_narapidana c ON b.id_narapidana = c.id_narapidana WHERE a.id_periode = '$idp'");
?>
<div class="container-fluid">
	<h3 align="center">DATA PENILAIAN <br><?php echo $data['keterangan']; ?></h3>
	<table width="100%" style="text-align: left; border-collapse: collapse; " border="1" class="table table-bordered" >
		<tr>
			<thead class="bg-success">
			<th>No</th>
			<!-- <th>ID Alternatif</th> -->
			<th>Nama Narapidana</th>
			<th><?php echo $k1; ?></th>
			<th><?php echo $k2; ?></th>
			<th><?php echo $k3; ?></th>
			<th><?php echo $k4; ?></th>
			<th><?php echo $k5; ?></th>
			</thead>
		</tr>
		<?php 
		$no = 1;
		while ($row = mysqli_fetch_array($q)) {
			?>
		<tr>
			<td><?php echo $no; ?></td>
			<td><?php echo $row["nama"]; ?></td>
			<td><?php echo $row["c1"]; ?></td>
			<td><?php echo $row["c2"]; ?></td>
			<td><?php echo $row["c3"]; ?></td>
			<td><?php echo $row["c4"]; ?></td>
			<td><?php echo $row["c5"]; ?></td>
			<!-- <td><?php echo $row[13]; ?></td> -->
			
		</tr>
		<?php	
		$no++;
		}
		 ?>
	</table>
</div>
<h4 style="margin-left: 70%;">Sijunjung, <?php echo date('d F Y') ?></h4>
<p style="margin-left: 70%;">A.n MENTERI HUKUM DAN HAM RI <br> DIREKTUR JENDERAL PEMASYARAKATAN.</p>
<div style="
	margin-left: 70%;
  border: 5px solid blue;
  padding-top: 10px;
  padding-right: 10px;
  padding-bottom: 10px;
  padding-left: 10px;
">
<p><img src="style/logo1.jpg" width="100px">Ditandatangin Secara Elektronik Oleh
<b style="margin-left: 27%;">Reynhard Sitilonga</b></p>
<p style="margin-left: 27%;">NIP : 670903320000001000</p>
</div>
</div>
</center>

</body>
?>