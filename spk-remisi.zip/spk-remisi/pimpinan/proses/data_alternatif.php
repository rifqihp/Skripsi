<?php 
	include ("style/header.php");
	include ("style/sidebar.php");
      $idp = $_GET['idp'];
?>
<div class="container-fluid">
	<div class="col-lg-12">
		<!-- Basic Card Example -->
		<div class="card shadow mt-3 mb-3">
			<div class="card-header py-3">
				<h6 class="m-0 font-weight-bold text-success">Data Alternatif</h6>
			</div>
			<div class="card-body">
				<!-- <button class="btn btn-sm btn-primary mb-3" data-toggle="modal" data-target="#tambah_mobil"><i class="fas fa-plus fa-sm"></i> Tambah Data</button> -->
        <a target="_blank" href="cetak_alt.php?idp=<?php echo $idp; ?>" class="btn btn-sm btn-success mb-3"><i class="fas fa-print"></i> Cetak</a>
      <div class="table-responsive">
				<table class="table table-bordered">
					<thead>
						<tr align="center">
							<th>No</th>
							<th>Nama Alternatif</th>
							<th>Jenis Kelamin</th>
              				<th>Tanggal Lahir</th>
							<th>Alamat</th>
							<th>Perkara Pidana</th>
							<th>Agama</th>
							<!-- <th colspan="2">Aksi</th> -->
						</tr>
					</thead>
					<?php 
						include("../../config/koneksi.php");
						$no=1;
						$sql = mysqli_query($konek, "SELECT * FROM tbl_alternatif a LEFT JOIN tbl_narapidana b ON a.id_narapidana = b.id_narapidana WHERE a.id_periode = '$idp'");
						while($array = mysqli_fetch_assoc($sql)){
					?>
					<tbody>
						<tr>
							<td><?php echo $no++; ?></td>
							<td><?php echo $array['nama']; ?></td>
							<td><?php echo $array['jenis_kelamin']; ?></td>
							<td><?php echo $array['tgl_lahir']; ?></td>
							<td><?php echo $array['alamat']; ?></td>
							<td><?php echo $array['perkara']; ?></td>
							<td><?php echo $array['agama']; ?></td>
								
							<!-- <td>
								<a href="edit_alternatif.php?id=<?php echo $array['id_alternatif']; ?>&idp=<?php echo $idp; ?>"><i class="btn btn-success btn-sm"><span class="fas fa-edit"></span></i></a>
							</td>

							<td>
								<a href="hapus_alternatif.php?id=<?php echo $array['id_alternatif']; ?>&idp=<?php echo $idp; ?>"><i class="btn btn-danger btn-sm"><span class="fas fa-trash"></span></i></a>
							</td> -->
						</tr>
					</tbody>
					<?php 
					} 
					?>
				</table>
      </div>
			<div align="right">
	<a href="data_kriteria.php?&idp=<?php echo $idp; ?>" class="btn btn-primary">Next</a>
</div>
			</div>

		</div>
	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="tambah_mobil" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Form Entry Data Alternatif</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      	<form action="" method="POST" enctype="multipart/form-data">
      		<div class="form-group">
            <label>Nama Alternatif</label>
      			<select class="form-control" name="id_narapidana" >
      			<option>--nama--</option>
      			<?php  
            $sql2 = mysqli_query($konek, "SELECT * FROM tbl_narapidana");
      			while($data2 = mysqli_fetch_array($sql2)){
			      ?>
      			<option value="<?= $data2['id_narapidana'] ?>"><?= $data2['nama']; ?></option>
                <?php } ?>
      			</select>

            
                       
      		</div>
      </div>
      <div class="modal-footer">
        <button type="submit" name="tambah" class="btn btn-primary btn-sm">Tambah</button>
      </div>
      	</form>
			
    </div>
</div>
  </div>
</div>


<?php 
	include ("../../config/koneksi.php");
	if (isset($_POST['tambah'])) {
      $idn 		    		= $_POST['id_narapidana'];
      // $tanggal 		    = $_POST['tanggal'];
    
	$save = mysqli_query($konek,"INSERT INTO tbl_alternatif VALUES('','$idn','$idp')");

	if($save) {
      echo "<script language=javascript>
          window.alert('Berhasil Menambah!');
          window.location='data_alternatif.php?idp=$idp';
          </script>";
      }else{
        echo "<script language=javascript>
          window.alert('Gagal Menambah!');
          window.location='data_alternatif.php?idp=$idp';
          </script>";
      }
}
?>

<?php 
	include ("style/footer.php");
?>