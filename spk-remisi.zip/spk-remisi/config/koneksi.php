<?php 
	$server = "localhost";
	$user	= "root";
	$pass	= "";
	$db		= "spkremisi";

	$konek	= mysqli_connect($server, $user, $pass, $db);
?>