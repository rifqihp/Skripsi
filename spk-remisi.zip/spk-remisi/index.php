  <?php 
	include ("style/header.php");
	include ("style/sidebar.php");
?>
        <!-- Content -->
    <div class="content">
        <div class="text-center mt-3">
            <img src="img/logo1.jpg" width="200px;">
            <h1><b>SPK METODE SAW</b></h1>
            <h6><b>Rekomendasi Pemberian Remisi Pada Narapidana Di Lembaga Pemasyarakatan Kelas II B Kota Muaro Sijunjung
            </b></h6>
         
        </div>
      
        <div class="container-fluid mt-3">
            <div class="card shadow mt-3 mb-2">
                <div class="card-header py-3">
                    <h4 class="m-0 font-weight-bold text-primary ">Singkat Tentang Metode SAW</h4>
                </div>
                   
                    <div class="card-body">
                        <h3 class="text-center">Singkat Tentang Metode SAW</h3>
                        <h6 class="m-3">Simple Additive Weighting (SAW) sering juga dikenal istilah
                        metode penjumlahan terbobot. Konsep dasar metode SAW adalah mencari penjumlahan terbobot dari rating kinerja pada setiap alternatif pada semua atribut (Fishburn, 1967) (Mac Crimmon, 1968).</h6>
                    </div>
            </div>
        </div>
    </div>
        </div> <!-- end content -->
    </div><!-- /#right-panel -->

    <!-- Right Panel -->
<?php
	include ("style/footer.php");
?>