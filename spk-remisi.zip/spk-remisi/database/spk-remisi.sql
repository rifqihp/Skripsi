-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 23, 2021 at 11:59 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spk-remisi`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_alternatif`
--

CREATE TABLE `tbl_alternatif` (
  `id_alternatif` int(3) NOT NULL,
  `id_narapidana` int(3) NOT NULL,
  `id_periode` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_alternatif`
--

INSERT INTO `tbl_alternatif` (`id_alternatif`, `id_narapidana`, `id_periode`) VALUES
(15, 9, 9),
(16, 10, 9),
(17, 11, 9),
(18, 12, 9),
(19, 13, 9),
(20, 14, 9),
(21, 15, 9),
(23, 16, 9),
(24, 17, 9),
(25, 18, 9),
(26, 19, 9),
(27, 20, 9),
(28, 21, 9),
(29, 22, 9),
(30, 23, 9),
(31, 24, 9),
(32, 25, 9),
(33, 26, 9),
(34, 27, 9),
(35, 28, 9),
(36, 29, 9),
(37, 30, 9),
(38, 31, 9),
(39, 32, 9),
(40, 33, 9),
(41, 34, 9),
(42, 35, 9),
(43, 36, 9),
(44, 37, 9),
(45, 38, 9),
(46, 39, 9),
(47, 40, 9),
(48, 41, 9),
(49, 42, 9),
(50, 43, 9),
(51, 44, 9),
(52, 45, 9),
(53, 46, 9),
(54, 47, 9),
(66, 48, 9),
(67, 49, 9),
(68, 50, 9),
(69, 51, 9),
(70, 52, 9),
(71, 53, 9),
(72, 54, 9),
(73, 55, 9),
(74, 56, 9),
(75, 57, 9),
(76, 58, 9),
(77, 9, 8),
(78, 10, 8),
(79, 11, 8),
(80, 12, 8),
(143, 59, 9);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_hasil`
--

CREATE TABLE `tbl_hasil` (
  `id_hasil` int(11) NOT NULL,
  `id_alternatif` int(11) NOT NULL,
  `id_periode` int(11) NOT NULL,
  `hasil` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_hasil`
--

INSERT INTO `tbl_hasil` (`id_hasil`, `id_alternatif`, `id_periode`, `hasil`) VALUES
(42, 15, 9, 0.91),
(44, 17, 9, 0.8725),
(45, 26, 9, 0.84),
(46, 27, 9, 0.65),
(48, 16, 9, 0.815),
(49, 17, 9, 0),
(50, 26, 9, 0),
(51, 27, 9, 0),
(52, 16, 9, 0),
(53, 27, 9, 0),
(54, 27, 9, 0.6875);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kriteria`
--

CREATE TABLE `tbl_kriteria` (
  `id_kriteria` varchar(10) NOT NULL,
  `nama_kriteria` varchar(50) NOT NULL,
  `jenis_kriteria` varchar(10) NOT NULL,
  `bobot` double(4,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_kriteria`
--

INSERT INTO `tbl_kriteria` (`id_kriteria`, `nama_kriteria`, `jenis_kriteria`, `bobot`) VALUES
('KRT001', 'Berkelakuan Baik', 'Benefit', 0.40),
('KRT002', 'Kegiatan Keagamaan', 'Benefit', 0.25),
('KRT003', 'Perkara Pidana', 'Benefit', 0.15),
('KRT004', 'Berjasa', 'Benefit', 0.15),
('KRT005', 'Kegiatan Pelatihan', 'Benefit', 0.05);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_narapidana`
--

CREATE TABLE `tbl_narapidana` (
  `id_narapidana` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jenis_kelamin` varchar(15) NOT NULL,
  `alamat` text NOT NULL,
  `agama` varchar(10) NOT NULL,
  `perkara` varchar(100) NOT NULL,
  `tgl_masuk` date NOT NULL,
  `tgl_keluar` date NOT NULL,
  `hukuman` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_narapidana`
--

INSERT INTO `tbl_narapidana` (`id_narapidana`, `nama`, `tgl_lahir`, `jenis_kelamin`, `alamat`, `agama`, `perkara`, `tgl_masuk`, `tgl_keluar`, `hukuman`) VALUES
(9, 'MOHAMAD SUBIANTO', '1996-10-26', 'Laki-laki', 'JL.LASWI RT.03/06 KEL.WARGAMEKAR KEC.BALEENDAH KAB.BANDUNG.', 'Islam', 'Perampokan', '2019-04-12', '2027-04-12', '8 Tahun'),
(10, 'RIKO AGUSTIAN', '1982-05-03', 'Laki-laki', 'JL KAMPUNG TARANDAM NO 52 KEL GANTING PARAK GADANG KEC PADANG TIMUR KOTA PADANG', 'Islam', 'Pencurian', '2020-02-22', '2021-11-22', '1 Tahun 8 bulan'),
(11, 'MUHAMMAD RINALDI', '1994-06-16', 'Laki-laki', 'JL DR SUTOMO NO 68 RT 001 RW 003 KEL KUBU MARAPALAM KEC PADANG TIMUR KOTA PADANG', 'Islam', 'Pencurian', '2018-12-04', '2022-06-04', '3 Tahun 6 Bulan'),
(12, 'DICKO CHANDRA KIRANA', '1998-05-02', 'Laki-laki', 'JL AUR DURI I NO 27 C RT 001 RW 001 KEL PARAK GADANG TIMUR KEC PADANG TIMUR KOTA PADANG\r\n', 'Islam', 'Narkotika', '2018-12-04', '2026-12-04', '8 Tahun'),
(13, 'RIKI', '1988-10-23', 'Laki-laki', 'KASIAK JORONG RUMAH PANJANG NAGARI KOTO SANI KECAMATAN X KOTO SINGKARAK KABUPATEN SOLOK', 'Islam', 'Memeras', '2019-10-28', '2022-10-28', '3 Tahun'),
(14, 'BOY SANDI', '1988-01-20', 'Laki-laki', 'JL TANAH TUMBUH RT 003 RW 000 KEL TELUK PANJANG KEC BATHIN III KAB BUNGO JAMBI', 'Islam', 'Narkotika', '2018-12-04', '2026-12-04', '8 Tahun'),
(15, 'YAMI REZITO', '1995-08-12', 'Laki-laki', 'JL AUR DURI BARU NO 11 RT 003 RW 002 KEL PARAK GADANG TIMUR KEC PADANG TIMUR KOTA PADANG', 'Islam', 'Narkotika', '2018-12-04', '2026-12-04', '8 Tahun'),
(16, 'ASWADI LUBIS', '1978-11-05', 'Laki-laki', 'TAMIANG JOR.SAROHA NAG.UJUNG GADING KEC.LEMBAH MELINTANG KAB.PASAMAN BARAT', 'Islam', 'Narkotika', '2019-10-28', '2023-10-28', '4 Tahun'),
(17, 'MUHAMMAD ZULHAIRY', '1988-05-25', 'Laki-laki', 'JORONG KOTO SERIKAT KENAGARIAN KUBANG KECAMATAN GUGUK KABUPATEN LIMA PULUH KOTA', 'Islam', 'Perlindungan Anak', '2019-03-11', '2033-03-11', '14 Tahun'),
(18, 'ADRANI', '1949-11-14', 'Laki-laki', 'JORONG LIMBANANG BARUAH KENAGARIAN LIMBANANG KECAMATAN SULIKI KABUPATEN LIMA PULUH KOTA', 'Islam', 'Perlindungan Anak', '2019-03-11', '2033-03-11', '14 Tahun'),
(19, 'RAJU SUSANDI', '1998-12-22', 'Laki-laki', 'JORONG SIBOKA KENAGARIAN ANDIANG KECAMATAN SULIKI KABUPATEN LIMA PULUH KOTA', 'Islam', 'Pencurian', '2019-12-19', '2022-12-19', '3 Tahun'),
(20, 'DEDE HIDAYAT ', '1986-08-11', 'Laki-laki', 'JORONG BALAI TALANG KENAGARIAN GUGUK VIII KOTO KECAMATAN GUGUK KABUPATEN LIMA PULUH KOTA', 'Islam', 'Perlindungan Anak', '2019-03-11', '2031-03-11', '12 Tahun'),
(21, 'ROZALI EFENDI', '1990-03-01', 'Laki-laki', 'JORONG KOTO TUO KENAGARIAN MUNGKA KABUPATEN LIMA PULUH KOTA', 'Islam', 'Narkotika', '2018-11-28', '2026-11-28', '8 Tahun'),
(22, 'ANGEL ENDRIKO', '1989-03-09', 'Laki-laki', 'JOR.KOTO GADANG NAG.PADANG GANTING KEC.PADANG GANTING KAB.TANAH DATAR', 'Islam', 'Perlindungan Anak', '2020-02-15', '2032-02-15', '12 Tahun'),
(23, 'JAMILUS', '1978-01-01', 'Laki-laki', 'JOR.KINAWAI NAG,BALIMBING KEC.RAMBATAN KAB.TANAH DATAR', 'Islam', 'Narkotika', '2020-02-15', '2026-02-15', '6 Tahun'),
(24, 'WENDRI PUTRA', '2000-09-18', 'Laki-laki', 'JOR.OMBILIN NAG.SIMAWANG KEC.RAMBATAN KAB.TANAH DATAR', 'Islam', 'Perlindungan Anak', '2019-07-19', '2031-07-19', '12 Tahun'),
(25, 'REDOL FEBRI ANDA', '2000-02-01', 'Laki-laki', 'JORONG KINAWAI NAGARI BALIMBING KECAMATAN RAMBATAN KABUPATEN TANAH DATAR\r\n', 'Islam', 'Perlindungan Anak', '2019-05-16', '2031-05-16', '12 Tahun'),
(26, 'ISMAIL', '1988-06-05', 'Laki-laki', 'JORONG KOTA NAGARI TAPI SELO KECAMATAN LINTAU BUO UTARA KABUPATEN TANAH DATAR', 'Islam', 'Perlindungan Anak', '2019-05-16', '2031-05-16', '12 Tahun'),
(27, 'BOBY ANNIKO', '1996-10-18', 'Laki-laki', 'JORONG KOTO GADANG HILIR, NAGARI PADANG GANTING, KECAMATAN PADANG GANTING, KABUPATEN TANAH DATAR', 'Islam', 'Perlindungan Anak', '2019-05-16', '2031-05-16', '12 Tahun'),
(28, 'ISRIZAL', '1970-08-31', 'Laki-laki', 'JORONG JATI TUNGGAL, NAGARI BUO, KECAMATAN LINTAU BUO, KABUPATEN TANAH DATAR', 'Islam', 'Narkotika', '2018-09-19', '2024-09-19', '6 Tahun'),
(29, 'KHAIRUL YUSUF', '1985-05-05', 'Laki-laki', 'Meunasah Baroh Kec.Simpang Kramat Kab.Aceh Utara Prop.NAD', 'Islam', 'Narkotika', '2019-01-31', '2023-01-31', '4 Tahun'),
(30, 'ARY HELVY FAJRIAN', '1998-12-06', 'Laki-laki', 'Jorong Batu Menjulur Timur Kenagarian Batu Menjulur Kecamatan Kupitan Kabupaten Sijunjung', 'Islam', 'Narkotika', '2019-03-18', '2023-03-18', '4 Tahun'),
(31, 'NASRIL', '1963-08-08', 'Laki-laki', 'Desa Kolok Mudik Kecamatan Barangin Kota Sawahlunto', 'Islam', 'Perlindungan Anak', '2018-07-06', '2032-07-06', '14 Tahun'),
(32, 'JASMAN', '0074-06-11', 'Laki-laki', 'Lansono Dusun Balai-Balai Desa Muaro Kalaban Kec. Silungkang Kota Sawahlunto', 'Islam', 'Perlindungan Anak', '2018-07-06', '2030-07-06', '12 Tahun'),
(33, 'YUDA SAPUTRA', '1979-07-01', 'Laki-laki', 'Dusun Tengku A Gani Mahbmud Kelurahan Menasah Timu Kecamatan Peusangan Kabupaten Bireuen Propinsi Aceh', 'Islam', 'Perusakan Hutan', '2020-12-18', '2022-06-18', '1 Tahun 6 Bulan'),
(34, 'RIYESKI RAHMADIA', '1996-05-01', 'Laki-laki', 'JOR. SUBARANG NAG. BATIPUAH ATEH KEC. BATIPUAH KAB. TANAH DATAR', 'Islam', 'Narkotika', '2019-12-06', '2027-12-06', '8 Tahun'),
(35, 'SASA ISMAIL', '1982-06-06', 'Laki-laki', 'Jorong Kamang Makmur Kenagarian KamanG baru Kecamatan Kamang Baru Kabupaten Sijunjung', 'Islam', 'Penadahan', '2020-12-18', '2022-01-18', '1 Tahun 1 Bulan'),
(36, 'PERLY AGUSTIN', '1997-08-14', 'Laki-laki', 'Jorong Ranah Kayu Kalek Nagari Silago Kecamatan Sembilan Koto Kabupaten Dharmasraya', 'Islam', 'Perlindungan Anak', '2018-02-15', '2030-02-15', '12 Tahun'),
(37, 'RYIKO TRILAYUNDA', '1990-07-21', 'Laki-laki', 'Jl. Hubulluawatan RT 002 RW 019 Kel Air Jamban Kec. Mandau Keb. Bengkalis Prop. Riau', 'Islam', 'Narkotika', '2018-02-09', '2024-02-09', '6 Tahun'),
(38, 'WAHYU ADITYA', '1998-05-28', 'Laki-laki', 'Pasar Tanjung Ampalu Kenagarian Limo Koto Kecamatan Koto VII Kabupaten Sijunjung', 'Islam', 'Perlindungan Anak', '2018-01-15', '2030-01-15', '12 Tahun'),
(39, 'FAISAL ASDONI', '1986-09-11', 'Laki-laki', 'Jr. Tanjung Pauh Ken. Muaro Bodi Kec. IV Nagari Kab. Sijunjung', 'Islam', 'Narkotika', '2017-05-23', '2023-05-23', '6 Tahun'),
(40, 'ANGGA FERDIANSA', '1990-06-25', 'Laki-laki', 'Jorong Lambau Nagari Sungai Kambut Kecamatan Pulau Punjung Kabupaten Dharmasraya', 'Islam', 'Narkotika', '2018-05-31', '2024-05-31', '6 Tahun'),
(41, 'NOFRIZAL', '1985-11-10', 'Laki-laki', 'Jr. Ranah Kenagarian Palaluar Kec. Koto VII Kab. Sijunjung', 'Islam', 'Perlindungan Anak', '0017-09-07', '2029-09-07', '12 Tahun'),
(42, 'MUHAMMAD RIZKI', '1996-08-23', 'Laki-laki', 'Jr. Bukit Sembilan Nagari Alahan Nan Tigo Kec. Asam Jujuhan kab. Dharmasraya', 'Islam', 'Perlindungan Anak', '2017-08-16', '2031-08-16', '14 Tahun'),
(43, 'JONI YUDA EKA PUTRA', '1976-06-05', 'Laki-laki', 'Jr. Ranah Sigading Ken. Padang Laweh Kec. koto VII Kab. Sijunjung', 'Islam', 'Narkotika', '2017-06-21', '2025-06-21', '8 Tahun'),
(44, 'AGUSALIM', '1960-08-17', 'Laki-laki', 'Jr. Dusun Tuo Ken. Muaro Bodi Kec. IV Nagari Kab. Sijunjung\r\n', 'Islam', 'Perlindungan Anak', '2017-06-19', '2029-06-19', '12 Tahun'),
(45, 'ILHAM SYAHPUTRA', '1998-04-04', 'Laki-laki', 'Jr. Koto Ken. Tj Lolo Kec. Tj. Gadang Kab. Sijunjung', 'Islam', 'Perlindungan Anak', '2017-05-25', '2029-05-25', '12 Tahun'),
(46, 'BUDIMAN HERISUSANTO', '2017-06-25', 'Laki-laki', 'Jr. Batang Dikek Ken. Tj. Lolo Kec. Tj Gadang Kab. Sijunjung', 'Islam', 'Perlindungan Anak', '2017-05-25', '2029-05-20', '12 Tahun'),
(47, 'FEMI ANDIKA SAPUTRA', '1997-05-27', 'Laki-laki', 'Jr. Koto Ken. Tj Lolo Kec. Tj Gadang Kab. Sijunjung', 'Islam', 'Perlindungan Anak', '2017-05-25', '2029-05-25', '12 Tahun'),
(48, 'VONY ABDUL RAZAK', '1992-11-19', 'Laki-laki', 'Jr. Pasar Baru Ken. Tanjung Lolo Kec. Tanjung Gadang Kab. Sijunjung', 'Islam', 'Perlindungan Anak', '2017-05-19', '2029-05-19', '12 Tahun'),
(49, 'RIKO ARIADI', '1986-11-04', 'Laki-laki', 'Jorong Guguk Naneh Ken Tanjung Gadang Kec Tanjung Gadang Kab Sijunjung', 'Islam', 'Narkotika', '2016-12-28', '2024-12-28', '8 Tahun'),
(50, 'LUKMAN LUBIS', '1963-09-08', 'Laki-laki', 'Jorong Koto Tangah Ken Padang Tarok Kec Kamang Baru Kab Sijunjung', 'Islam', 'Perlindungan Anak', '2016-12-19', '2028-12-19', '12 Tahun'),
(51, 'HENDRIK ERFENDI ', '1988-02-11', 'Laki-laki', 'Jorong Ranah Sigading Ken Padang Laweh Kec Koto VII Kab Sijunjung', 'Islam', 'Narkotika', '2016-11-17', '2024-11-17', '8 Tahun'),
(52, 'AMRION', '1967-09-04', 'Laki-laki', 'Desa Tamiai Kec Batang Merangin Kab Kerinci Prov Jambi\r\n', 'Islam', 'Perlindungan Anak', '2016-07-18', '2030-07-18', '14 Tahun'),
(53, 'RISKI AMALDI', '1981-10-11', 'Laki-laki', 'Jorong Muaro Mau Ken Sungai Kambut Kec Pulau Punjung Kab Dharmasraya', 'Islam', 'Narkotika', '2016-06-30', '2024-06-30', '8 Tahun'),
(54, 'AFRIANDY', '1979-04-12', 'Laki-laki', 'Jorong Talang Sungai Lansek Ken Sei Lansek Kec Kamang Baru Kab Sijunjung', 'Islam', 'Narkotika', '2019-10-02', '2025-10-02', '6 Tahun'),
(55, 'YURNALIS ', '1964-06-10', 'Laki-laki', 'Jorong Koto Ken Buluh Kasok Kec Lubuk Tarok Kab Sijunjung\r\n', 'Islam', 'Perlindungan Anak', '2015-06-17', '2027-06-17', '12 Tahun'),
(56, 'IRVA YUHALMI', '1983-03-12', 'Laki-laki', 'Jrg Pasar Koto Baru Kaen Koto Baru Kab Dharmasraya\r\n', 'Islam', 'Narkotika', '2015-06-01', '2023-06-01', '8 Tahun'),
(57, 'RAHMAN ', '1989-11-10', 'Laki-laki', 'RT.003 RW 003 KEL. IBUAH KEC. PAYAKUMBUH BARAT KOTA PAYAKUMBUH', '--Agama--', 'Pencurian', '2019-10-28', '2022-10-28', '3 Tahun'),
(58, 'MAIZUL ASRI', '1963-05-03', 'Laki-laki', 'RT 002 RW 004 KEL. BALAI NAN TUO KECAMATAN PAYAKUMBUH UTARA KOTA PAYAKUMBUH/ KEL. NAN KODOK NO .33 KEC. PAYAKUMBUH UTARA\r\n', 'Islam', 'Perlindungan Anak', '2018-11-28', '2032-11-28', '14 Tahun'),
(59, 'Martha', '2021-09-15', 'Laki-laki', 'Padang', 'Islam', 'Maliang', '2021-09-11', '2021-10-09', 'Kurungan 5 Tahun');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_normalisasi`
--

CREATE TABLE `tbl_normalisasi` (
  `id_normalisasi` int(11) NOT NULL,
  `id_alternatif` int(11) NOT NULL,
  `id_periode` int(11) NOT NULL,
  `id_kriteria` varchar(11) NOT NULL,
  `nilai_normalisasi` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_normalisasi`
--

INSERT INTO `tbl_normalisasi` (`id_normalisasi`, `id_alternatif`, `id_periode`, `id_kriteria`, `nilai_normalisasi`) VALUES
(280, 27, 9, 'KRT001', 0.6),
(281, 27, 9, 'KRT002', 0.75),
(282, 27, 9, 'KRT003', 0.6),
(283, 27, 9, 'KRT004', 1),
(284, 27, 9, 'KRT005', 0.4);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_penilaian`
--

CREATE TABLE `tbl_penilaian` (
  `id_penilaian` int(11) NOT NULL,
  `id_alternatif` int(11) NOT NULL,
  `id_periode` int(11) NOT NULL,
  `id_subkriteria` int(11) NOT NULL,
  `ket` enum('B','S') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_penilaian`
--

INSERT INTO `tbl_penilaian` (`id_penilaian`, `id_alternatif`, `id_periode`, `id_subkriteria`, `ket`) VALUES
(86, 16, 9, 10, 'S'),
(87, 16, 9, 14, 'S'),
(88, 16, 9, 18, 'S'),
(89, 16, 9, 24, 'S'),
(90, 16, 9, 25, 'S'),
(91, 17, 9, 10, 'S'),
(92, 17, 9, 14, 'S'),
(93, 17, 9, 17, 'S'),
(94, 17, 9, 27, 'S'),
(95, 17, 9, 26, 'S'),
(96, 26, 9, 1, 'S'),
(97, 26, 9, 15, 'S'),
(98, 26, 9, 18, 'S'),
(99, 26, 9, 23, 'S'),
(100, 26, 9, 28, 'S'),
(101, 27, 9, 11, 'S'),
(102, 27, 9, 15, 'S'),
(103, 27, 9, 19, 'S'),
(104, 27, 9, 23, 'S'),
(105, 27, 9, 28, 'S');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_periode`
--

CREATE TABLE `tbl_periode` (
  `id_periode` int(3) NOT NULL,
  `keterangan` varchar(50) NOT NULL,
  `tahun` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_periode`
--

INSERT INTO `tbl_periode` (`id_periode`, `keterangan`, `tahun`) VALUES
(9, 'Periode Remisi 2021', '2021-05-13');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subkriteria`
--

CREATE TABLE `tbl_subkriteria` (
  `id_subkriteria` int(11) NOT NULL,
  `id_kriteria` varchar(50) NOT NULL,
  `ket` varchar(100) NOT NULL,
  `nbobot` double(4,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_subkriteria`
--

INSERT INTO `tbl_subkriteria` (`id_subkriteria`, `id_kriteria`, `ket`, `nbobot`) VALUES
(1, 'KRT001', 'Sangat Baik', 0.50),
(10, 'KRT001', 'Cukup Baik', 0.40),
(11, 'KRT001', 'Kurang Baik', 0.30),
(12, 'KRT001', 'Tidak Baik', 0.20),
(13, 'KRT002', 'Sangat Baik', 0.50),
(14, 'KRT002', 'Cukup Baik', 0.40),
(15, 'KRT002', 'Kurang Baik', 0.30),
(16, 'KRT002', 'Tidak Baik', 0.20),
(17, 'KRT003', 'Sangat Baik', 0.50),
(18, 'KRT003', 'Cukup Baik', 0.40),
(19, 'KRT003', 'Kurang Baik', 0.30),
(20, 'KRT003', 'Tidak Baik', 0.20),
(21, 'KRT004', 'Sangat Baik ', 0.50),
(22, 'KRT004', 'Cukup Baik', 0.40),
(23, 'KRT004', 'Kurang Baik', 0.30),
(24, 'KRT004', 'Tidak Baik', 0.20),
(25, 'KRT005', 'Sangat Baik', 0.50),
(26, 'KRT005', 'Cukup Baik', 0.40),
(27, 'KRT004', 'Kurang Baik ', 0.30),
(28, 'KRT005', 'Tidak Baik', 0.20);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(3) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `level` varchar(15) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `username`, `password`, `level`, `nama_lengkap`) VALUES
(1, 'admin', 'admin', 'Admin', 'RHP'),
(2, 'pimpinan', 'pimpinan', 'Pimpinan', 'B.O. Situngkir, AMd. IP, SH, MH ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_alternatif`
--
ALTER TABLE `tbl_alternatif`
  ADD PRIMARY KEY (`id_alternatif`);

--
-- Indexes for table `tbl_hasil`
--
ALTER TABLE `tbl_hasil`
  ADD PRIMARY KEY (`id_hasil`);

--
-- Indexes for table `tbl_kriteria`
--
ALTER TABLE `tbl_kriteria`
  ADD PRIMARY KEY (`id_kriteria`);

--
-- Indexes for table `tbl_narapidana`
--
ALTER TABLE `tbl_narapidana`
  ADD PRIMARY KEY (`id_narapidana`);

--
-- Indexes for table `tbl_normalisasi`
--
ALTER TABLE `tbl_normalisasi`
  ADD PRIMARY KEY (`id_normalisasi`);

--
-- Indexes for table `tbl_penilaian`
--
ALTER TABLE `tbl_penilaian`
  ADD PRIMARY KEY (`id_penilaian`);

--
-- Indexes for table `tbl_periode`
--
ALTER TABLE `tbl_periode`
  ADD PRIMARY KEY (`id_periode`);

--
-- Indexes for table `tbl_subkriteria`
--
ALTER TABLE `tbl_subkriteria`
  ADD PRIMARY KEY (`id_subkriteria`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_alternatif`
--
ALTER TABLE `tbl_alternatif`
  MODIFY `id_alternatif` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;

--
-- AUTO_INCREMENT for table `tbl_hasil`
--
ALTER TABLE `tbl_hasil`
  MODIFY `id_hasil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `tbl_narapidana`
--
ALTER TABLE `tbl_narapidana`
  MODIFY `id_narapidana` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `tbl_normalisasi`
--
ALTER TABLE `tbl_normalisasi`
  MODIFY `id_normalisasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=285;

--
-- AUTO_INCREMENT for table `tbl_penilaian`
--
ALTER TABLE `tbl_penilaian`
  MODIFY `id_penilaian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT for table `tbl_periode`
--
ALTER TABLE `tbl_periode`
  MODIFY `id_periode` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_subkriteria`
--
ALTER TABLE `tbl_subkriteria`
  MODIFY `id_subkriteria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
