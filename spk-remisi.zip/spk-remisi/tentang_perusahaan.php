<?php 
	include ("style/header.php");
	include ("style/sidebar.php");
?>
<div class="container-fluid">
	<div class="col-lg-12">
		<!-- Basic Card Example -->
		<div class="card shadow mt-3 mb-3">
			<div class="card-header py-3">
				<h6 class="m-0 font-weight-bold text-primary">Lembaga Pemasyarakatan Kelas II B Kota Muaro Sijunjung</h6>
			</div>
			<div class="card-body">
				<p>Didirikan		: Tahun 1979
				<br>
				Dioperasionalkan      	: Tahun 1983
				<br>Lembaga Pemasyarakatan sebagai Unit Pelaksana Teknis diatur dalam Keputusan Menteri Kehakiman No.M.01.PR.07.03 Tahun 1995 tentang Organisasi dan Tata Kerja. Lembaga Pemasyarakatan berada dibawah dan bertanggung jawab kepada  Kantor Wilayah Kementerian Hukum dan HAM Sumatera Barat
</p>
			</div>
		</div>
	</div>
</div>
<?php 
	include ("style/footer.php");
?>